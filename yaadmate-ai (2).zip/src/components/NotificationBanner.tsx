import React, { useState, useEffect } from 'react';
import {
  Bell,
  Check,
  Clock,
  X,
  Volume2,
  VolumeX,
  Sparkles,
  RotateCcw,
  Square,
} from 'lucide-react';
import { Reminder, AppLanguage, AlarmSoundType } from '../types/reminder';
import { translations } from '../utils/translations';
import {
  triggerHaptic,
  startAlarmRingtone,
  stopAlarmRingtone,
} from '../utils/sound';
import {
  speakReminderAnnouncement,
  stopSpeaking,
} from '../utils/speechSynthesis';

interface NotificationBannerProps {
  permission: NotificationPermission | 'unsupported';
  onRequestPermission: () => void;
  language: AppLanguage;
  activeDueReminder: Reminder | null;
  soundEnabled: boolean;
  vibrateEnabled: boolean;
  speechAnnouncementsEnabled: boolean;
  alarmSound: AlarmSoundType;
  onDismissDueAlert: () => void;
  onCompleteDueReminder: (id: string) => void;
  onQuickSnooze: (reminderId: string, minutes: number) => void;
  onOpenCustomPostpone: (reminder: Reminder) => void;
}

export const NotificationBanner: React.FC<NotificationBannerProps> = ({
  permission,
  onRequestPermission,
  language,
  activeDueReminder,
  soundEnabled,
  vibrateEnabled,
  speechAnnouncementsEnabled,
  alarmSound,
  onDismissDueAlert,
  onCompleteDueReminder,
  onQuickSnooze,
  onOpenCustomPostpone,
}) => {
  const t = translations[language];
  const [dismissBanner, setDismissBanner] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  // Manage alarm ringtone and spoken announcement when due reminder appears
  useEffect(() => {
    if (activeDueReminder) {
      setIsMuted(false);

      // Start looping alarm if sound is enabled
      if (soundEnabled) {
        startAlarmRingtone(alarmSound, vibrateEnabled);
      } else if (vibrateEnabled) {
        triggerHaptic([300, 150, 300, 150, 400]);
      }

      // Spoken voice announcement if enabled
      if (speechAnnouncementsEnabled) {
        speakReminderAnnouncement(
          activeDueReminder.title,
          activeDueReminder.category,
          language
        );
      }
    } else {
      stopAlarmRingtone();
      stopSpeaking();
    }

    return () => {
      stopAlarmRingtone();
      stopSpeaking();
    };
  }, [
    activeDueReminder,
    soundEnabled,
    vibrateEnabled,
    speechAnnouncementsEnabled,
    alarmSound,
    language,
  ]);

  const handleToggleMute = () => {
    if (isMuted) {
      setIsMuted(false);
      startAlarmRingtone(alarmSound, vibrateEnabled);
    } else {
      setIsMuted(true);
      stopAlarmRingtone();
      stopSpeaking();
    }
  };

  const handleComplete = () => {
    stopAlarmRingtone();
    stopSpeaking();
    if (activeDueReminder) {
      onCompleteDueReminder(activeDueReminder.id);
    }
  };

  const handleSnoozeMinutes = (minutes: number) => {
    stopAlarmRingtone();
    stopSpeaking();
    if (activeDueReminder) {
      onQuickSnooze(activeDueReminder.id, minutes);
    }
  };

  const handleSpeakAgain = () => {
    if (activeDueReminder) {
      speakReminderAnnouncement(
        activeDueReminder.title,
        activeDueReminder.category,
        language
      );
    }
  };

  return (
    <>
      {/* 1. In-App Due Reminder Alarm Modal */}
      {activeDueReminder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in zoom-in-95">
          <div className="w-full max-w-sm rounded-3xl bg-gradient-to-b from-[#19153b] via-[#0f172a] to-[#070b14] border-2 border-indigo-500/50 p-5 shadow-2xl text-center relative overflow-hidden">
            {/* Pulsing glow background */}
            <div className="absolute -top-12 -left-12 w-32 h-32 bg-indigo-500/30 rounded-full blur-2xl pointer-events-none animate-pulse" />
            <div className="absolute -bottom-12 -right-12 w-32 h-32 bg-purple-500/30 rounded-full blur-2xl pointer-events-none animate-pulse" />

            <div className="relative z-10 space-y-3">
              {/* Top Bell & Mute Control */}
              <div className="flex items-center justify-between">
                <button
                  onClick={handleSpeakAgain}
                  title="Speak reminder aloud again"
                  className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-indigo-300 border border-white/10 transition-colors"
                >
                  <Volume2 className="w-4 h-4" />
                </button>

                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-500 via-purple-500 to-pink-500 text-white flex items-center justify-center shadow-lg shadow-indigo-500/50 animate-bounce">
                  <Bell className="w-6 h-6" />
                </div>

                <button
                  onClick={handleToggleMute}
                  title={isMuted ? 'Unmute Alarm' : 'Silence Ringtone'}
                  className={`p-2 rounded-xl border transition-colors ${
                    isMuted
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                      : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 border-white/10'
                  }`}
                >
                  {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
              </div>

              {/* Status Badge */}
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 text-xs font-bold">
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                ALARM DUE NOW
              </span>

              {/* Title & Notes */}
              <div>
                <h2 className="text-lg font-bold text-white leading-snug">
                  {activeDueReminder.title}
                </h2>
                {activeDueReminder.description && (
                  <p className="text-xs text-slate-300 mt-2 bg-slate-900/70 p-2.5 rounded-xl border border-white/10 text-left">
                    {activeDueReminder.description}
                  </p>
                )}
              </div>

              <p className="text-xs text-indigo-300 font-semibold flex items-center justify-center gap-1.5">
                <Clock className="w-3.5 h-3.5" />
                Scheduled for {activeDueReminder.time} • {activeDueReminder.category}
              </p>

              {/* Quick Snooze Options Strip */}
              <div className="pt-1">
                <span className="block text-[10px] uppercase font-bold text-slate-400 mb-1.5 tracking-wider">
                  Quick Snooze
                </span>
                <div className="grid grid-cols-4 gap-1.5">
                  {[
                    { label: '+5m', mins: 5 },
                    { label: '+10m', mins: 10 },
                    { label: '+15m', mins: 15 },
                    { label: '+1h', mins: 60 },
                  ].map((snooze) => (
                    <button
                      key={snooze.mins}
                      onClick={() => handleSnoozeMinutes(snooze.mins)}
                      className="py-1.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-amber-300 font-bold text-xs border border-amber-500/20 transition-all active:scale-95"
                    >
                      {snooze.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Primary STOP ALARM Button */}
              <button
                onClick={() => {
                  stopAlarmRingtone();
                  stopSpeaking();
                  onDismissDueAlert();
                }}
                className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-bold text-sm shadow-xl shadow-rose-600/40 flex items-center justify-center gap-2 active:scale-95 transition-all"
              >
                <Square className="w-4 h-4 fill-white stroke-none" />
                Stop Alarm
              </button>

              {/* Secondary Buttons: Mark Done & Custom Snooze */}
              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  onClick={() => {
                    stopAlarmRingtone();
                    stopSpeaking();
                    onOpenCustomPostpone(activeDueReminder);
                  }}
                  className="w-full py-2.5 px-3 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-xs font-semibold text-amber-300 border border-amber-500/25 transition-all active:scale-95 flex items-center justify-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                  Custom Snooze
                </button>

                <button
                  onClick={handleComplete}
                  className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-xs font-bold text-white shadow-lg shadow-emerald-600/30 transition-all active:scale-95 flex items-center justify-center gap-1.5"
                >
                  <Check className="w-4 h-4 stroke-[3]" />
                  Mark Done
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. Soft permission banner (if permission is default and not dismissed) */}
      {permission === 'default' && !dismissBanner && (
        <div className="mx-4 mt-3 p-3.5 rounded-2xl bg-gradient-to-r from-indigo-950/70 to-slate-900 border border-indigo-500/25 flex items-start gap-3 shadow-lg relative">
          <div className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0 border border-indigo-500/30">
            <Bell className="w-4 h-4" />
          </div>

          <div className="flex-1 min-w-0 pr-5">
            <h4 className="text-xs font-bold text-white mb-0.5">
              {t.notifications.title}
            </h4>
            <p className="text-[11px] text-slate-300 leading-relaxed mb-2">
              {t.notifications.desc}
            </p>
            <button
              onClick={onRequestPermission}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-[11px] shadow-md shadow-indigo-600/30 transition-all active:scale-95"
            >
              {t.notifications.enableBtn}
            </button>
          </div>

          <button
            onClick={() => setDismissBanner(true)}
            className="absolute top-2.5 right-2.5 p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </>
  );
};
