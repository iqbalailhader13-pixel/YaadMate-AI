import React from 'react';
import { Home, Bot, History, Settings, MessageSquare, Plus } from 'lucide-react';
import { TabType, AppLanguage } from '../types/reminder';
import { translations } from '../utils/translations';

interface BottomNavProps {
  currentTab: TabType;
  onSelectTab: (tab: TabType) => void;
  onOpenAddModal: () => void;
  language: AppLanguage;
  pendingCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onSelectTab,
  onOpenAddModal,
  language,
  pendingCount,
}) => {
  const t = translations[language];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#070b14]/95 backdrop-blur-xl border-t border-white/[0.08] px-2 py-1.5 pb-safe max-w-lg mx-auto">
      <div className="flex items-center justify-around relative">
        {/* Dashboard */}
        <button
          onClick={() => onSelectTab('home')}
          className={`flex flex-col items-center justify-center flex-1 py-1 rounded-xl transition-all ${
            currentTab === 'home'
              ? 'text-indigo-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className="relative">
            <Home className="w-5 h-5 transition-transform active:scale-90" />
            {pendingCount > 0 && (
              <span className="absolute -top-1 -right-2 min-w-[15px] h-[15px] px-1 text-[9px] font-bold rounded-full bg-indigo-500 text-white flex items-center justify-center">
                {pendingCount > 99 ? '99+' : pendingCount}
              </span>
            )}
          </div>
          <span className="text-[10px] mt-1 tracking-tight">{t.tabs.home}</span>
        </button>

        {/* AI Assistant */}
        <button
          onClick={() => onSelectTab('chat')}
          className={`flex flex-col items-center justify-center flex-1 py-1 rounded-xl transition-all ${
            currentTab === 'chat'
              ? 'text-indigo-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className="relative">
            <Bot className="w-5 h-5 transition-transform active:scale-90" />
            <span className="absolute -top-0.5 -right-1 w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
          </div>
          <span className="text-[10px] mt-1 tracking-tight">{t.tabs.chat}</span>
        </button>

        {/* Center Floating Add Button */}
        <div className="flex-1 flex justify-center -mt-5">
          <button
            onClick={onOpenAddModal}
            title={t.actions.addReminder}
            className="w-12 h-12 rounded-full bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 text-white shadow-lg shadow-indigo-600/40 flex items-center justify-center border-2 border-[#070b14] active:scale-90 transition-transform focus:outline-none"
          >
            <Plus className="w-6 h-6 stroke-[2.5]" />
          </button>
        </div>

        {/* History / Completed */}
        <button
          onClick={() => onSelectTab('history')}
          className={`flex flex-col items-center justify-center flex-1 py-1 rounded-xl transition-all ${
            currentTab === 'history'
              ? 'text-indigo-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <History className="w-5 h-5 transition-transform active:scale-90" />
          <span className="text-[10px] mt-1 tracking-tight">{t.tabs.history}</span>
        </button>

        {/* WhatsApp & Settings */}
        <button
          onClick={() => onSelectTab('whatsapp')}
          className={`flex flex-col items-center justify-center flex-1 py-1 rounded-xl transition-all ${
            currentTab === 'whatsapp'
              ? 'text-emerald-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <MessageSquare className="w-5 h-5 transition-transform active:scale-90" />
          <span className="text-[10px] mt-1 tracking-tight">{t.tabs.whatsapp}</span>
        </button>

        <button
          onClick={() => onSelectTab('settings')}
          className={`flex flex-col items-center justify-center flex-1 py-1 rounded-xl transition-all ${
            currentTab === 'settings'
              ? 'text-indigo-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Settings className="w-5 h-5 transition-transform active:scale-90" />
          <span className="text-[10px] mt-1 tracking-tight">{t.tabs.settings}</span>
        </button>
      </div>
    </nav>
  );
};
