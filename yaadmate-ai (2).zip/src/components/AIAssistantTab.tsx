import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Mic,
  MicOff,
  Sparkles,
  Bot,
  User,
  Plus,
  CheckCircle2,
  Calendar,
  Clock,
  Repeat,
  Tag,
  Flag,
  Trash2,
  AlertCircle,
  HelpCircle,
  Languages,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { Reminder, AppLanguage } from '../types/reminder';
import { translations } from '../utils/translations';
import { triggerHaptic, playNotificationChime } from '../utils/sound';
import { speakSpokenText, stopSpeaking } from '../utils/speechSynthesis';
import { getApiUrl } from '../utils/apiConfig';
import confetti from 'canvas-confetti';

interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
  action?: {
    type: string;
    data?: any;
  };
  confirmed?: boolean;
}

interface AIAssistantTabProps {
  reminders: Reminder[];
  onAddReminder: (data: Omit<Reminder, 'id' | 'createdAt' | 'completed' | 'postponeCount'>) => void;
  language: AppLanguage;
  onNavigateTab: (tab: 'home' | 'history' | 'settings') => void;
}

export const AIAssistantTab: React.FC<AIAssistantTabProps> = ({
  reminders,
  onAddReminder,
  language,
  onNavigateTab,
}) => {
  const t = translations[language];
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome-msg',
      role: 'model',
      text:
        language === 'ur'
          ? 'السلام علیکم! میں یاد میٹ AI ہوں۔ آپ مجھے کسی بھی کام، میٹنگ، یا دوا کا یاد دلانے کے لیے اردو، رومن اردو یا انگریزی میں کہہ سکتے ہیں۔'
          : language === 'ur-roman'
          ? 'Assalam-o-Alaikum! Main aapka YaadMate AI assistant hoon. Kisi bhi task, meeting ya dawa ka reminder lagane ke liye mujhe bataiye ya microphone se bolein.'
          : 'Hello! I am YaadMate AI. You can tell me in English, Roman Urdu, or Urdu to set reminders, check your schedule, or ask what tasks are pending.',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [voiceLang, setVoiceLang] = useState<'ur-PK' | 'en-US'>(() =>
    language === 'ur' ? 'ur-PK' : 'en-US'
  );
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);
  const [speechError, setSpeechError] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  // Clean up any ongoing TTS speech on unmount
  useEffect(() => {
    return () => {
      stopSpeaking();
    };
  }, []);

  // Multilingual prompt suggestions for English, Urdu, and Roman Urdu
  const promptSuggestions = [
    'Kal subah 9:30 baje doctor appointment yaad dilao',
    'Rozana shaam 7 baje walk ka reminder lagao',
    'Sawa 4 baje team standup meeting',
    'Dawaai leni hai har roz raat 10 baje',
    'Fajr ke baad jogging ka reminder',
    'Remind me tomorrow at 8 AM to pay electricity bill',
    'Show me all pending reminders',
    'Har jumma subah 11 baje car wash',
  ];

  // Send message
  const handleSendMessage = async (textToSend?: string) => {
    const userText = (textToSend || input).trim();
    if (!userText || loading) return;

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setLoading(true);
    setSpeechError(null);
    triggerHaptic(30);

    try {
      // Clean history so turns start with user role and alternate correctly
      const cleanHistory: { role: 'user' | 'model'; text: string }[] = [];
      let firstUserFound = false;
      for (const m of messages.slice(-6)) {
        if (m.role === 'user') firstUserFound = true;
        if (firstUserFound) {
          cleanHistory.push({ role: m.role, text: m.text });
        }
      }

      const response = await fetch(getApiUrl('/api/gemini/chat'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userText,
          history: cleanHistory,
          reminders,
          currentDateTime: new Date().toISOString(),
          userLanguage: language,
        }),
      });

      const data = await response.json();

      const aiMessage: Message = {
        id: `ai-${Date.now()}`,
        role: 'model',
        text: data.reply || (data.error ? `Error: ${data.error}` : "I've processed your request."),
        action: data.action,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, aiMessage]);
      playNotificationChime();
    } catch (err) {
      console.error('Chat error:', err);
      setMessages((prev) => [
        ...prev,
        {
          id: `ai-err-${Date.now()}`,
          role: 'model',
          text:
            'I encountered a temporary connection issue. You can still create reminders manually using the "+" button on your screen.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  // Confirm and schedule reminder extracted from AI
  const handleConfirmReminder = (msgId: string, reminderData: any) => {
    if (!reminderData || !reminderData.title) return;

    onAddReminder({
      title: reminderData.title,
      description: reminderData.description || '',
      date: reminderData.date || new Date().toISOString().split('T')[0],
      time: reminderData.time || '09:00',
      category: reminderData.category || 'Personal',
      priority: reminderData.priority || 'medium',
      recurrence: reminderData.recurrence || 'none',
    });

    confetti({
      particleCount: 50,
      spread: 70,
      origin: { y: 0.6 },
    });
    triggerHaptic([40, 50, 100]);

    setMessages((prev) =>
      prev.map((m) => (m.id === msgId ? { ...m, confirmed: true } : m))
    );
  };

  // Voice speech-to-text handler
  const handleToggleVoice = () => {
    setSpeechError(null);

    if (isListening) {
      setIsListening(false);
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setSpeechError('Voice input is not supported in this browser. Please type your message.');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = voiceLang;

      recognition.onstart = () => {
        setIsListening(true);
        triggerHaptic(40);
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          setInput(transcript);
          handleSendMessage(transcript);
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        const msg =
          event.error === 'not-allowed' || event.error === 'permission-denied'
            ? 'Microphone permission denied. Allow microphone in your browser settings or use text entry.'
            : event.error === 'no-speech'
            ? 'No speech detected. Please speak into your microphone and try again.'
            : `Voice error (${event.error}). Please type your request directly.`;
        setSpeechError(msg);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch (err) {
      console.error('Speech recognition error:', err);
      setSpeechError('Microphone access could not be initialized. Please use text entry.');
      setIsListening(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] max-w-lg mx-auto">
      {/* Assistant Header Badge */}
      <div className="p-3.5 mx-4 mt-2 rounded-2xl bg-gradient-to-r from-purple-950/40 via-indigo-950/40 to-slate-900 border border-purple-500/20 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center border border-purple-500/30">
            <Bot className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-xs font-bold text-white flex items-center gap-1.5">
              {t.chat.title}
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            </h2>
            <p className="text-[10px] text-slate-400">{t.chat.subtitle}</p>
          </div>
        </div>

        <button
          onClick={() =>
            setMessages([
              {
                id: `reset-${Date.now()}`,
                role: 'model',
                text: 'Conversation cleared. How can I help you remember today?',
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              },
            ])
          }
          title="Clear chat history"
          className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3.5">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex items-start gap-2.5 ${
              msg.role === 'user' ? 'flex-row-reverse' : ''
            }`}
          >
            {/* Avatar */}
            <div
              className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 text-white ${
                msg.role === 'user'
                  ? 'bg-gradient-to-tr from-indigo-600 to-blue-500'
                  : 'bg-gradient-to-tr from-purple-600 to-pink-500 shadow-md shadow-purple-600/30'
              }`}
            >
              {msg.role === 'user' ? (
                <User className="w-3.5 h-3.5" />
              ) : (
                <Sparkles className="w-3.5 h-3.5" />
              )}
            </div>

            {/* Bubble */}
            <div className={`max-w-[82%] space-y-2`}>
              <div
                className={`p-3 rounded-2xl text-xs leading-relaxed relative ${
                  msg.role === 'user'
                    ? 'bg-indigo-600 text-white rounded-tr-xs'
                    : 'bg-[#0f172a] border border-white/10 text-slate-200 rounded-tl-xs shadow-sm'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <p className="whitespace-pre-wrap flex-1">{msg.text}</p>
                  {msg.role === 'model' && (
                    <button
                      type="button"
                      onClick={() => {
                        if (speakingMsgId === msg.id) {
                          stopSpeaking();
                          setSpeakingMsgId(null);
                        } else {
                          stopSpeaking();
                          setSpeakingMsgId(msg.id);
                          const cleanText = msg.text.replace(/[*_#`]/g, '').trim();
                          speakSpokenText(cleanText, language);
                        }
                      }}
                      title={speakingMsgId === msg.id ? 'Stop reading' : 'Read aloud'}
                      className="p-1 rounded-md text-slate-400 hover:text-indigo-300 hover:bg-white/10 transition-colors shrink-0"
                    >
                      {speakingMsgId === msg.id ? (
                        <VolumeX className="w-3.5 h-3.5 text-pink-400 animate-pulse" />
                      ) : (
                        <Volume2 className="w-3.5 h-3.5" />
                      )}
                    </button>
                  )}
                </div>
                <span className="block text-[9px] text-right mt-1 opacity-60">
                  {msg.timestamp}
                </span>
              </div>

              {/* Action Card: Reminder Confirmation */}
              {msg.action && msg.action.type === 'create_reminder' && msg.action.data && (
                <div className="p-3.5 rounded-2xl bg-gradient-to-br from-indigo-950/80 to-purple-950/60 border border-indigo-500/40 shadow-lg text-xs space-y-2.5 animate-in zoom-in-95">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-purple-400" />
                      Parsed Reminder
                    </span>
                    <span className="px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 text-[10px] font-semibold">
                      {msg.action.data.category || 'Personal'}
                    </span>
                  </div>

                  <h4 className="font-bold text-white text-sm">
                    {msg.action.data.title}
                  </h4>

                  {msg.action.data.description && (
                    <p className="text-[11px] text-slate-300">
                      {msg.action.data.description}
                    </p>
                  )}

                  <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-300">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-indigo-400" />
                      {msg.action.data.date}
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-indigo-400" />
                      {msg.action.data.time}
                    </span>
                    {msg.action.data.recurrence && msg.action.data.recurrence !== 'none' && (
                      <>
                        <span>•</span>
                        <span className="flex items-center gap-1 text-purple-300">
                          <Repeat className="w-3 h-3" />
                          {msg.action.data.recurrence}
                        </span>
                      </>
                    )}
                  </div>

                  {msg.confirmed ? (
                    <div className="flex items-center gap-1.5 text-emerald-400 text-xs font-semibold py-1">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{t.chat.reminderCreated}</span>
                    </div>
                  ) : (
                    <button
                      onClick={() => handleConfirmReminder(msg.id, msg.action?.data)}
                      className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:to-pink-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-indigo-600/30 transition-all active:scale-95"
                    >
                      <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                      {t.chat.confirmReminder}
                    </button>
                  )}
                </div>
              )}

              {/* Action Card: View Reminders Link */}
              {msg.action && msg.action.type === 'view_reminders' && (
                <button
                  onClick={() => onNavigateTab('home')}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 text-xs font-semibold border border-indigo-500/30 flex items-center gap-1.5 transition-colors"
                >
                  Go to Dashboard →
                </button>
              )}
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex items-center gap-2 text-slate-400 text-xs pl-9">
            <div className="flex gap-1">
              <span className="w-2 h-2 rounded-full bg-purple-400 animate-bounce" />
              <span className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce [animation-delay:0.2s]" />
              <span className="w-2 h-2 rounded-full bg-pink-400 animate-bounce [animation-delay:0.4s]" />
            </div>
            <span>YaadMate is thinking...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompt Chips */}
      <div className="px-4 py-1.5">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-[11px]">
          {promptSuggestions.map((suggestion, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(suggestion)}
              className="shrink-0 px-2.5 py-1 rounded-full bg-slate-900/90 hover:bg-slate-800 border border-white/10 hover:border-indigo-500/40 text-slate-300 hover:text-white transition-all active:scale-95"
            >
              {suggestion}
            </button>
          ))}
        </div>
      </div>

      {/* Voice Active Bar */}
      {isListening && (
        <div className="mx-4 mb-2 p-2 rounded-xl bg-rose-950/60 border border-rose-500/40 flex items-center justify-between animate-pulse">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
            <span className="text-xs font-semibold text-rose-200">
              {t.chat.voiceListening}
            </span>
            <div className="flex items-center gap-1 ml-2">
              <span className="w-1 bg-rose-400 rounded-full animate-wave-1" />
              <span className="w-1 bg-rose-400 rounded-full animate-wave-2" />
              <span className="w-1 bg-rose-400 rounded-full animate-wave-3" />
              <span className="w-1 bg-rose-400 rounded-full animate-wave-4" />
            </div>
          </div>
          <button
            onClick={() => setIsListening(false)}
            className="text-[10px] text-rose-300 underline font-semibold"
          >
            Stop
          </button>
        </div>
      )}

      {speechError && (
        <p className="mx-4 mb-2 text-[11px] text-amber-300 flex items-center gap-1 bg-amber-950/40 p-1.5 rounded-lg border border-amber-500/20">
          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
          {speechError}
        </p>
      )}

      {/* Input Row */}
      <div className="p-3 bg-[#070b14] border-t border-white/[0.08]">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center gap-2"
        >
          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              onClick={handleToggleVoice}
              title={`Voice Input (${voiceLang === 'ur-PK' ? 'Urdu Voice' : 'English / Roman Urdu Voice'})`}
              className={`p-2.5 rounded-xl border transition-all active:scale-95 ${
                isListening
                  ? 'bg-rose-500 border-rose-400 text-white animate-pulse'
                  : 'bg-slate-800 border-white/10 text-slate-300 hover:text-white'
              }`}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>
            <button
              type="button"
              onClick={() => {
                setVoiceLang((prev) => (prev === 'ur-PK' ? 'en-US' : 'ur-PK'));
                triggerHaptic(20);
              }}
              title="Click to toggle Voice Language (Urdu / Roman Urdu & English)"
              className="px-2 py-1.5 rounded-lg bg-slate-800/90 border border-white/10 hover:border-indigo-400/40 text-[10px] font-bold text-slate-300 hover:text-indigo-300 transition-all active:scale-95 shadow-sm"
            >
              {voiceLang === 'ur-PK' ? 'اردو' : 'EN/Roman'}
            </button>
          </div>

          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={t.chat.inputPlaceholder}
            className="flex-1 bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-400"
          />

          <button
            type="submit"
            disabled={!input.trim() || loading}
            className="p-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white disabled:opacity-40 transition-all active:scale-95 shadow-md shadow-indigo-600/30"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
