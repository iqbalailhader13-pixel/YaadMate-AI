import React, { useState } from 'react';
import {
  Check,
  Clock,
  Repeat,
  MoreVertical,
  Edit2,
  Trash2,
  Share2,
  Calendar,
  AlertCircle,
  Briefcase,
  HeartPulse,
  ShoppingBag,
  Video,
  Star,
  CreditCard,
  User,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { Reminder, ReminderCategory, ReminderPriority, AppLanguage } from '../types/reminder';
import { translations } from '../utils/translations';
import confetti from 'canvas-confetti';
import { playSuccessChime, triggerHaptic } from '../utils/sound';

import { getLocalTodayString } from '../utils/dateUtils';

interface ReminderCardProps {
  reminder: Reminder;
  language: AppLanguage;
  soundEnabled: boolean;
  vibrateEnabled: boolean;
  onToggleComplete: (id: string) => void;
  onOpenEdit: (reminder: Reminder) => void;
  onOpenPostpone: (reminder: Reminder) => void;
  onDelete: (id: string) => void;
  onShareToWhatsApp: (reminder: Reminder) => void;
}

export const ReminderCard: React.FC<ReminderCardProps> = ({
  reminder,
  language,
  soundEnabled,
  vibrateEnabled,
  onToggleComplete,
  onOpenEdit,
  onOpenPostpone,
  onDelete,
  onShareToWhatsApp,
}) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const t = translations[language];

  // Helper for Category Icon
  const getCategoryIcon = (category: ReminderCategory) => {
    switch (category) {
      case 'Work':
        return <Briefcase className="w-3.5 h-3.5 text-blue-400" />;
      case 'Health':
        return <HeartPulse className="w-3.5 h-3.5 text-rose-400" />;
      case 'Shopping':
        return <ShoppingBag className="w-3.5 h-3.5 text-amber-400" />;
      case 'Meeting':
        return <Video className="w-3.5 h-3.5 text-purple-400" />;
      case 'Important':
        return <Star className="w-3.5 h-3.5 text-yellow-400" />;
      case 'Finance':
        return <CreditCard className="w-3.5 h-3.5 text-emerald-400" />;
      default:
        return <User className="w-3.5 h-3.5 text-indigo-400" />;
    }
  };

  // Helper for Priority Styling
  const getPriorityBadge = (priority: ReminderPriority) => {
    switch (priority) {
      case 'urgent':
        return {
          bg: 'bg-rose-500/15 text-rose-400 border-rose-500/30',
          dot: 'bg-rose-500',
          label: t.priorities.urgent,
        };
      case 'high':
        return {
          bg: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
          dot: 'bg-amber-500',
          label: t.priorities.high,
        };
      case 'medium':
        return {
          bg: 'bg-indigo-500/15 text-indigo-300 border-indigo-500/30',
          dot: 'bg-indigo-400',
          label: t.priorities.medium,
        };
      default:
        return {
          bg: 'bg-slate-700/40 text-slate-400 border-slate-600/30',
          dot: 'bg-slate-400',
          label: t.priorities.low,
        };
    }
  };

  // Determine time status (due today, overdue, upcoming)
  const computeTimeStatus = () => {
    const now = new Date();
    const reminderDate = new Date(`${reminder.date}T${reminder.time}:00`);
    const diffMs = reminderDate.getTime() - now.getTime();
    const diffMins = Math.round(diffMs / (1000 * 60));

    const todayStr = getLocalTodayString(now);
    const isToday = reminder.date === todayStr;

    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const isTomorrow = reminder.date === getLocalTodayString(tomorrow);

    if (reminder.completed) {
      return {
        label: `${reminder.date} at ${reminder.time}`,
        isOverdue: false,
        statusText: 'Completed',
        color: 'text-slate-400',
      };
    }

    if (diffMins < 0) {
      const absMins = Math.abs(diffMins);
      const hours = Math.floor(absMins / 60);
      const mins = absMins % 60;
      const overdueText = hours > 0 ? `${hours}h ${mins}m ago` : `${mins}m ago`;
      return {
        label: `${reminder.date} at ${reminder.time}`,
        isOverdue: true,
        statusText: `Overdue (${overdueText})`,
        color: 'text-rose-400 font-semibold',
      };
    }

    if (isToday) {
      if (diffMins < 60) {
        return {
          label: `Today at ${reminder.time}`,
          isOverdue: false,
          statusText: `Due in ${diffMins}m`,
          color: 'text-amber-400 font-semibold',
        };
      }
      return {
        label: `Today at ${reminder.time}`,
        isOverdue: false,
        statusText: `Today at ${reminder.time}`,
        color: 'text-indigo-300',
      };
    }

    if (isTomorrow) {
      return {
        label: `Tomorrow at ${reminder.time}`,
        isOverdue: false,
        statusText: `Tomorrow at ${reminder.time}`,
        color: 'text-slate-300',
      };
    }

    return {
      label: `${reminder.date} at ${reminder.time}`,
      isOverdue: false,
      statusText: `${reminder.date} • ${reminder.time}`,
      color: 'text-slate-400',
    };
  };

  const timeStatus = computeTimeStatus();
  const priorityInfo = getPriorityBadge(reminder.priority);

  const handleToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!reminder.completed) {
      if (soundEnabled) playSuccessChime();
      if (vibrateEnabled) triggerHaptic([50, 40, 80]);
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#6366f1', '#a855f7', '#10b981', '#38bdf8'],
      });
    }
    onToggleComplete(reminder.id);
  };

  return (
    <div
      className={`relative rounded-2xl p-4 transition-all duration-200 border ${
        reminder.completed
          ? 'bg-slate-900/40 border-white/[0.04] opacity-65'
          : timeStatus.isOverdue
          ? 'bg-[#121226] border-rose-500/30 hover:border-rose-500/50 shadow-md shadow-rose-950/20'
          : 'bg-[#0f172a]/90 hover:bg-[#131d35] border-white/[0.08] hover:border-indigo-500/40 shadow-sm'
      }`}
    >
      <div className="flex items-start gap-3">
        {/* Completion Checkbox Button */}
        <button
          onClick={handleToggle}
          title={reminder.completed ? 'Mark uncompleted' : 'Mark completed'}
          className={`mt-0.5 w-6 h-6 rounded-full flex items-center justify-center transition-all shrink-0 active:scale-90 ${
            reminder.completed
              ? 'bg-emerald-500 text-white shadow-sm shadow-emerald-500/30 ring-2 ring-emerald-500/20'
              : 'border-2 border-slate-500 hover:border-indigo-400 bg-transparent text-transparent hover:text-indigo-400'
          }`}
        >
          <Check className="w-3.5 h-3.5 stroke-[3]" />
        </button>

        {/* Card Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <h3
              onClick={() => onOpenEdit(reminder)}
              className={`font-semibold text-sm leading-snug cursor-pointer transition-colors ${
                reminder.completed
                  ? 'line-through text-slate-500'
                  : 'text-slate-100 hover:text-indigo-300'
              }`}
            >
              {reminder.title}
            </h3>

            {/* Overflow options button */}
            <div className="relative">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setMenuOpen(!menuOpen);
                }}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800/80 transition-colors"
              >
                <MoreVertical className="w-4 h-4" />
              </button>

              {menuOpen && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={(e) => {
                      e.stopPropagation();
                      setMenuOpen(false);
                    }}
                  />
                  <div
                    onClick={(e) => e.stopPropagation()}
                    className="absolute right-0 top-7 z-50 w-44 rounded-xl bg-slate-900 border border-white/10 shadow-xl py-1.5 backdrop-blur-xl animate-in fade-in zoom-in-95 text-xs font-medium"
                  >
                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        onOpenEdit(reminder);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-slate-200 hover:bg-slate-800 transition-colors"
                    >
                      <Edit2 className="w-3.5 h-3.5 text-indigo-400" />
                      {t.actions.edit}
                    </button>
                    {!reminder.completed && (
                      <button
                        onClick={() => {
                          setMenuOpen(false);
                          onOpenPostpone(reminder);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-slate-200 hover:bg-slate-800 transition-colors"
                      >
                        <Clock className="w-3.5 h-3.5 text-amber-400" />
                        {t.actions.postpone}
                      </button>
                    )}
                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        onShareToWhatsApp(reminder);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-slate-200 hover:bg-slate-800 transition-colors"
                    >
                      <Share2 className="w-3.5 h-3.5 text-emerald-400" />
                      Share / WhatsApp
                    </button>
                    <div className="my-1 border-t border-white/10" />
                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        onDelete(reminder.id);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-rose-400 hover:bg-rose-500/10 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      {t.actions.delete}
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Description snippet */}
          {reminder.description && (
            <div className="mt-1">
              <p
                onClick={() => setExpanded(!expanded)}
                className={`text-xs text-slate-400 cursor-pointer ${
                  expanded ? 'whitespace-pre-wrap' : 'line-clamp-2'
                }`}
              >
                {reminder.description}
              </p>
              {reminder.description.length > 90 && (
                <button
                  onClick={() => setExpanded(!expanded)}
                  className="text-[11px] text-indigo-400 hover:underline flex items-center gap-0.5 mt-0.5"
                >
                  {expanded ? (
                    <>Show less <ChevronUp className="w-3 h-3" /></>
                  ) : (
                    <>Show more <ChevronDown className="w-3 h-3" /></>
                  )}
                </button>
              )}
            </div>
          )}

          {/* Date, Time, and Status row */}
          <div className="flex flex-wrap items-center gap-2 mt-2.5 text-xs">
            {/* Time / Countdown badge */}
            <div className={`flex items-center gap-1 ${timeStatus.color}`}>
              {timeStatus.isOverdue ? (
                <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
              ) : (
                <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              )}
              <span>{timeStatus.statusText}</span>
            </div>

            {/* Recurrence Indicator */}
            {reminder.recurrence !== 'none' && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-purple-500/15 text-purple-300 border border-purple-500/30 text-[11px] font-medium">
                <Repeat className="w-3 h-3" />
                {t.recurrences[reminder.recurrence]}
              </span>
            )}

            {/* Category Chip */}
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-white/5 text-[11px] font-medium">
              {getCategoryIcon(reminder.category)}
              {t.categories[reminder.category]}
            </span>

            {/* Priority Indicator */}
            <span
              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md border text-[11px] font-medium ${priorityInfo.bg}`}
            >
              <span className={`w-1.5 h-1.5 rounded-full ${priorityInfo.dot}`} />
              {priorityInfo.label}
            </span>

            {/* Postpone count badge if snoozed */}
            {reminder.postponeCount && reminder.postponeCount > 0 ? (
              <span className="text-[10px] text-amber-400/80 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">
                Snoozed {reminder.postponeCount}x
              </span>
            ) : null}
          </div>

          {/* Quick Action Buttons for uncompleted reminders */}
          {!reminder.completed && (
            <div className="flex items-center gap-2 mt-3 pt-2 border-t border-white/[0.05]">
              <button
                onClick={() => onOpenPostpone(reminder)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 text-[11px] font-medium text-slate-300 hover:text-white transition-colors"
              >
                <Clock className="w-3 h-3 text-amber-400" />
                {t.actions.postpone}
              </button>

              <button
                onClick={() => onShareToWhatsApp(reminder)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-950/40 hover:bg-emerald-900/60 text-[11px] font-medium text-emerald-300 border border-emerald-500/20 transition-colors"
              >
                <Share2 className="w-3 h-3 text-emerald-400" />
                WhatsApp
              </button>

              <div className="flex-1" />

              <button
                onClick={handleToggle}
                className="flex items-center gap-1 px-3 py-1 rounded-lg bg-indigo-600/30 hover:bg-indigo-600/50 text-[11px] font-semibold text-indigo-200 border border-indigo-500/30 transition-colors"
              >
                <Check className="w-3 h-3" />
                {t.actions.complete}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
