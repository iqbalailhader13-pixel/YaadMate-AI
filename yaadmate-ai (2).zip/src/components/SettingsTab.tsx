import React, { useState, useEffect } from 'react';
import {
  Settings,
  Languages,
  Moon,
  Volume2,
  VolumeX,
  Vibrate,
  Bell,
  Download,
  Upload,
  RotateCcw,
  Sparkles,
  User,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Play,
  Smartphone,
  Zap,
} from 'lucide-react';
import { UserPreferences, AppLanguage, AppTheme, Reminder, AlarmSoundType } from '../types/reminder';
import { translations } from '../utils/translations';
import { playNotificationChime, playSuccessChime, triggerHaptic, playAlarmBurst } from '../utils/sound';
import { speakReminderAnnouncement } from '../utils/speechSynthesis';
import { getInitialReminders } from '../utils/storage';
import {
  isNativePlatform,
  checkExactAlarmPermission,
  requestExactAlarmPermission,
  YAADMATE_ALARM_CHANNEL_ID,
} from '../utils/nativeScheduler';
import { getApiUrl } from '../utils/apiConfig';

interface SettingsTabProps {
  preferences: UserPreferences;
  onUpdatePreferences: (updates: Partial<UserPreferences>) => void;
  reminders: Reminder[];
  onImportReminders: (imported: Reminder[]) => void;
  onResetReminders: () => void;
  onTriggerTestNotification: () => void;
  onOpenOnboarding: () => void;
}

export const SettingsTab: React.FC<SettingsTabProps> = ({
  preferences,
  onUpdatePreferences,
  reminders,
  onImportReminders,
  onResetReminders,
  onTriggerTestNotification,
  onOpenOnboarding,
}) => {
  const t = translations[preferences.language];
  const [nameInput, setNameInput] = useState(preferences.userName);
  const [aiStatus, setAiStatus] = useState<{ hasGeminiKey: boolean; loading: boolean }>({
    hasGeminiKey: false,
    loading: true,
  });
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [isNative, setIsNative] = useState(false);
  const [exactAlarmStatus, setExactAlarmStatus] = useState<'granted' | 'denied' | 'prompt'>('prompt');

  // Check backend Gemini status and native Android alarm settings
  useEffect(() => {
    setIsNative(isNativePlatform());
    checkExactAlarmPermission().then((status) => {
      setExactAlarmStatus(status);
    });

    fetch(getApiUrl('/api/status'))
      .then((res) => res.json())
      .then((data) => {
        setAiStatus({ hasGeminiKey: Boolean(data.hasGeminiKey), loading: false });
      })
      .catch(() => {
        setAiStatus({ hasGeminiKey: false, loading: false });
      });
  }, []);

  const handleNameSave = () => {
    onUpdatePreferences({ userName: nameInput.trim() || 'Friend' });
    triggerHaptic(30);
  };

  const [confirmReset, setConfirmReset] = useState(false);

  const handleExportData = () => {
    const dataStr = JSON.stringify(reminders, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `yaadmate_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    triggerHaptic(40);
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (Array.isArray(parsed)) {
          // Validate and sanitize each reminder object
          const validCategories = ['Work', 'Personal', 'Health', 'Shopping', 'Meeting', 'Important', 'Finance'];
          const validPriorities = ['low', 'medium', 'high', 'urgent'];
          const validRecurrences = ['none', 'daily', 'weekly', 'weekdays', 'monthly'];

          const sanitized: Reminder[] = parsed
            .filter((item) => item && typeof item === 'object')
            .map((item, idx) => ({
              id: typeof item.id === 'string' && item.id ? item.id : `imported-${Date.now()}-${idx}`,
              title: typeof item.title === 'string' && item.title.trim() ? item.title.trim() : 'Restored Reminder',
              description: typeof item.description === 'string' ? item.description : '',
              date: typeof item.date === 'string' && item.date ? item.date : new Date().toISOString().split('T')[0],
              time: typeof item.time === 'string' && item.time ? item.time : '09:00',
              category: validCategories.includes(item.category) ? item.category : 'Personal',
              priority: validPriorities.includes(item.priority) ? item.priority : 'medium',
              recurrence: validRecurrences.includes(item.recurrence) ? item.recurrence : 'none',
              completed: Boolean(item.completed),
              completedAt: item.completedAt,
              createdAt: item.createdAt || new Date().toISOString(),
              notified: Boolean(item.notified),
              postponeCount: typeof item.postponeCount === 'number' ? item.postponeCount : 0,
            }));

          onImportReminders(sanitized);
          setImportStatus(`Successfully restored ${sanitized.length} reminders!`);
          triggerHaptic([40, 50, 100]);
        } else {
          setImportStatus('Invalid backup file: Expected an array of reminders.');
        }
      } catch (err) {
        setImportStatus('Could not read backup file. Please ensure it is valid JSON.');
      } finally {
        e.target.value = ''; // Reset input so user can re-import the same file if needed
      }
    };
    reader.readAsText(file);
  };

  const themes: { id: AppTheme; label: string; bg: string }[] = [
    { id: 'navy', label: 'Dark Navy (Android)', bg: 'bg-[#070b14]' },
    { id: 'midnight', label: 'Midnight AMOLED', bg: 'bg-black' },
    { id: 'cyber', label: 'Cyber Indigo', bg: 'bg-[#0f0c29]' },
    { id: 'emerald', label: 'Deep Forest', bg: 'bg-[#061a14]' },
  ];

  return (
    <div className="p-4 space-y-4 max-w-lg mx-auto pb-24 text-xs">
      {/* AI Assistant Health Card */}
      <div className="p-4 rounded-3xl bg-gradient-to-br from-indigo-950/70 via-purple-950/40 to-slate-900 border border-indigo-500/30 shadow-xl">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center border border-purple-500/30">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-white text-sm">YaadMate Intelligence</h3>
              <p className="text-[11px] text-slate-400">Gemini 3.8 Flash Engine</p>
            </div>
          </div>

          <span
            className={`px-2.5 py-1 rounded-full text-[10px] font-bold flex items-center gap-1 ${
              aiStatus.hasGeminiKey
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
            }`}
          >
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                aiStatus.hasGeminiKey ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'
              }`}
            />
            {aiStatus.hasGeminiKey ? 'Gemini 3.8 Active' : 'Offline Rule Engine Active'}
          </span>
        </div>

        <p className="text-slate-300 text-[11px] leading-relaxed">
          {aiStatus.hasGeminiKey
            ? 'Full Gemini 3.8 Flash model connected. Natural language understanding active in English, Urdu, and Roman Urdu.'
            : 'Running high-precision offline parser. To enable advanced Gemini conversational reasoning, ensure GEMINI_API_KEY is configured in Settings > Secrets.'}
        </p>
      </div>

      {/* Language Preference */}
      <div className="p-4 rounded-3xl bg-[#0d1527] border border-white/10 space-y-3">
        <h4 className="font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
          <Languages className="w-4 h-4 text-indigo-400" />
          Language Selection
        </h4>

        <div className="grid grid-cols-3 gap-2">
          {[
            { id: 'en' as AppLanguage, label: 'English', sub: 'Default' },
            { id: 'ur-roman' as AppLanguage, label: 'Roman Urdu', sub: 'Aasan Urdu' },
            { id: 'ur' as AppLanguage, label: 'اردو', sub: 'Urdu Script' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => {
                onUpdatePreferences({ language: item.id });
                triggerHaptic(30);
              }}
              className={`p-3 rounded-2xl border text-center transition-all active:scale-95 ${
                preferences.language === item.id
                  ? 'bg-indigo-600 text-white border-indigo-400 shadow-md shadow-indigo-600/30 font-bold'
                  : 'bg-slate-900/60 text-slate-300 border-white/10 hover:border-white/20'
              }`}
            >
              <div className="font-semibold text-xs">{item.label}</div>
              <div className="text-[10px] text-slate-400 mt-0.5">{item.sub}</div>
            </button>
          ))}
        </div>
      </div>

      {/* User Profile / Greeting Name */}
      <div className="p-4 rounded-3xl bg-[#0d1527] border border-white/10 space-y-2.5">
        <h4 className="font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
          <User className="w-4 h-4 text-indigo-400" />
          Personalization
        </h4>

        <div className="flex items-center gap-2">
          <input
            type="text"
            value={nameInput}
            onChange={(e) => setNameInput(e.target.value)}
            placeholder="Your name for greetings..."
            className="flex-1 bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-400"
          />
          <button
            onClick={handleNameSave}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold transition-colors active:scale-95"
          >
            Save
          </button>
        </div>
      </div>

      {/* Audio & Haptic Notification Settings */}
      <div className="p-4 rounded-3xl bg-[#0d1527] border border-white/10 space-y-3">
        <h4 className="font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
          <Bell className="w-4 h-4 text-indigo-400" />
          Audio & Haptic Feedback
        </h4>

        {/* Sound toggle */}
        <div className="flex items-center justify-between py-1">
          <div>
            <div className="font-semibold text-white">Chime Sound Effects</div>
            <div className="text-[11px] text-slate-400">Play chime tone when reminders arrive</div>
          </div>
          <button
            onClick={() => {
              const next = !preferences.soundEnabled;
              onUpdatePreferences({ soundEnabled: next });
              if (next) playSuccessChime();
            }}
            className={`w-12 h-6 rounded-full transition-colors relative ${
              preferences.soundEnabled ? 'bg-indigo-600' : 'bg-slate-700'
            }`}
          >
            <span
              className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform ${
                preferences.soundEnabled ? 'right-1' : 'left-1'
              }`}
            />
          </button>
        </div>

        {/* Spoken Reminder Announcement toggle */}
        <div className="flex items-center justify-between py-1 border-t border-white/5 pt-2">
          <div>
            <div className="font-semibold text-white">Spoken Reminder Announcement</div>
            <div className="text-[11px] text-slate-400">Speaks task name aloud in English or Urdu</div>
          </div>
          <button
            onClick={() => {
              const next = !preferences.speechAnnouncementsEnabled;
              onUpdatePreferences({ speechAnnouncementsEnabled: next });
              if (next) {
                speakReminderAnnouncement('Water break', 'Health', preferences.language);
              }
            }}
            className={`w-12 h-6 rounded-full transition-colors relative ${
              preferences.speechAnnouncementsEnabled ? 'bg-indigo-600' : 'bg-slate-700'
            }`}
          >
            <span
              className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform ${
                preferences.speechAnnouncementsEnabled ? 'right-1' : 'left-1'
              }`}
            />
          </button>
        </div>

        {/* Alarm Ringtone Sound Selector */}
        <div className="py-1 border-t border-white/5 pt-2">
          <label className="block text-slate-300 font-semibold mb-1.5">
            Alarm Ringtone Style
          </label>
          <div className="grid grid-cols-3 gap-1.5">
            {(
              [
                { id: 'melodic', label: 'Melodic' },
                { id: 'digital', label: 'Digital' },
                { id: 'radar', label: 'Radar' },
              ] as const
            ).map((s) => (
              <button
                key={s.id}
                onClick={() => {
                  onUpdatePreferences({ alarmSound: s.id });
                  playAlarmBurst(s.id);
                  triggerHaptic(30);
                }}
                className={`py-1.5 px-2 rounded-xl text-center font-medium border text-xs transition-all flex items-center justify-center gap-1 ${
                  preferences.alarmSound === s.id
                    ? 'bg-indigo-600 text-white border-indigo-400 shadow-sm'
                    : 'bg-slate-900/60 text-slate-300 border-white/10 hover:border-white/20'
                }`}
              >
                <Play className="w-2.5 h-2.5 opacity-70" />
                {s.label}
              </button>
            ))}
          </div>
        </div>

        {/* Vibration toggle */}
        <div className="flex items-center justify-between py-1 border-t border-white/5 pt-2">
          <div>
            <div className="font-semibold text-white">Haptic Vibration</div>
            <div className="text-[11px] text-slate-400">Tactile buzz on buttons and alarms</div>
          </div>
          <button
            onClick={() => {
              const next = !preferences.vibrateEnabled;
              onUpdatePreferences({ vibrateEnabled: next });
              if (next) triggerHaptic(50);
            }}
            className={`w-12 h-6 rounded-full transition-colors relative ${
              preferences.vibrateEnabled ? 'bg-indigo-600' : 'bg-slate-700'
            }`}
          >
            <span
              className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform ${
                preferences.vibrateEnabled ? 'right-1' : 'left-1'
              }`}
            />
          </button>
        </div>

        {/* Test Buttons */}
        <div className="grid grid-cols-3 gap-1.5 pt-2 border-t border-white/5">
          <button
            onClick={() => {
              playNotificationChime();
              triggerHaptic(40);
            }}
            className="py-2 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium transition-colors flex items-center justify-center gap-1 text-[11px]"
          >
            <Volume2 className="w-3 h-3 text-indigo-400" />
            Chime
          </button>

          <button
            onClick={() => {
              speakReminderAnnouncement('Doctor appointment', 'Health', preferences.language);
              triggerHaptic(40);
            }}
            className="py-2 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium transition-colors flex items-center justify-center gap-1 text-[11px]"
          >
            <Volume2 className="w-3 h-3 text-purple-400" />
            Voice TTS
          </button>

          <button
            onClick={() => {
              onTriggerTestNotification();
            }}
            className="py-2 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium transition-colors flex items-center justify-center gap-1 text-[11px]"
          >
            <Bell className="w-3 h-3 text-amber-400" />
            Test Alarm
          </button>
        </div>

        {/* App Onboarding & Permissions Tour Link */}
        <div className="pt-2 border-t border-white/5">
          <button
            onClick={onOpenOnboarding}
            className="w-full py-2.5 px-3 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-indigo-300 font-medium border border-indigo-500/20 transition-all active:scale-98 flex items-center justify-center gap-1.5 text-xs"
          >
            <HelpCircle className="w-3.5 h-3.5 text-indigo-400" />
            View App Tour & Permissions Guide
          </button>
        </div>
      </div>

      {/* Android Native Alarms & Exact Notifications Card */}
      <div className="p-4 rounded-3xl bg-[#0d1527] border border-white/10 space-y-3">
        <h4 className="font-bold uppercase tracking-wider text-slate-300 flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <Smartphone className="w-4 h-4 text-emerald-400" />
            Android Alarms & Local Notifications
          </span>
          <span
            className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
              isNative ? 'bg-emerald-500/20 text-emerald-300' : 'bg-indigo-500/20 text-indigo-300'
            }`}
          >
            {isNative ? 'Native Capacitor APK' : 'Web / PWA Bridge'}
          </span>
        </h4>

        <div className="p-3 rounded-2xl bg-slate-900/80 border border-white/5 space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <span className="text-slate-400">Alarm Notification Channel:</span>
            <span className="font-mono text-indigo-300 text-[11px]">{YAADMATE_ALARM_CHANNEL_ID}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-400">Channel Importance:</span>
            <span className="text-emerald-300 font-semibold text-[11px]">
              Level 5 (Max / Heads-up Banner)
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-400">Wake from Doze (Exact Alarms):</span>
            <span className="text-slate-200 text-[11px]">
              {exactAlarmStatus === 'granted'
                ? '✅ Enabled (allowWhileIdle)'
                : '⚠️ Requires Android Setting'}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-400">Interactive Action Buttons:</span>
            <span className="text-slate-200 text-[11px]">Mark Complete, Snooze 10m, Snooze 1h</span>
          </div>
        </div>

        {isNative && exactAlarmStatus !== 'granted' && (
          <button
            onClick={async () => {
              const res = await requestExactAlarmPermission();
              setExactAlarmStatus(res);
            }}
            className="w-full py-2 px-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-medium text-xs flex items-center justify-center gap-1.5 transition-colors"
          >
            <Zap className="w-3.5 h-3.5" />
            Configure Exact Alarm Permission in Android Settings
          </button>
        )}
      </div>

      {/* Backup & Restore Data */}
      <div className="p-4 rounded-3xl bg-[#0d1527] border border-white/10 space-y-3">
        <h4 className="font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          Data & Backup Management
        </h4>

        <p className="text-[11px] text-slate-400">
          Your reminders are securely stored in your local browser storage. You can export a JSON backup at any time or restore previously saved tasks.
        </p>

        {importStatus && (
          <div className="p-2 rounded-xl bg-slate-800 text-indigo-300 text-xs">
            {importStatus}
          </div>
        )}

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={handleExportData}
            className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium transition-colors flex items-center justify-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            {t.actions.exportData}
          </button>

          <label className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium transition-colors flex items-center justify-center gap-1.5 cursor-pointer">
            <Upload className="w-3.5 h-3.5 text-purple-400" />
            <span>{t.actions.importData}</span>
            <input
              type="file"
              accept=".json"
              onChange={handleImportFile}
              className="hidden"
            />
          </label>
        </div>

        {/* Reset Demo Data Button */}
        <div className="pt-2 border-t border-white/5">
          {confirmReset ? (
            <div className="flex items-center justify-between p-2 rounded-xl bg-rose-950/40 border border-rose-500/30 animate-in fade-in">
              <span className="text-[11px] text-rose-300 font-medium">Reset all reminders to default demo items?</span>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => {
                    onResetReminders();
                    triggerHaptic(50);
                    setConfirmReset(false);
                  }}
                  className="px-2.5 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-[10px] font-bold"
                >
                  Yes, reset
                </button>
                <button
                  onClick={() => setConfirmReset(false)}
                  className="px-2 py-1 text-slate-400 hover:text-white text-[10px]"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => {
                triggerHaptic(20);
                setConfirmReset(true);
              }}
              className="w-full py-2 text-slate-400 hover:text-rose-400 transition-colors flex items-center justify-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset to Sample Reminders
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
