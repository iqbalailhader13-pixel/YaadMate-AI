import React, { useState } from 'react';
import { X, Clock, Calendar, Check, AlertCircle } from 'lucide-react';
import { Reminder, AppLanguage } from '../types/reminder';
import { translations } from '../utils/translations';
import { triggerHaptic } from '../utils/sound';

interface PostponeModalProps {
  isOpen: boolean;
  onClose: () => void;
  reminder: Reminder | null;
  language: AppLanguage;
  onPostpone: (reminderId: string, newDate: string, newTime: string) => void;
}

export const PostponeModal: React.FC<PostponeModalProps> = ({
  isOpen,
  onClose,
  reminder,
  language,
  onPostpone,
}) => {
  const t = translations[language];

  const [customMode, setCustomMode] = useState(false);
  const [customDate, setCustomDate] = useState('');
  const [customTime, setCustomTime] = useState('');

  if (!isOpen || !reminder) return null;

  const handleQuickPostpone = (minutesToAdd: number) => {
    const now = new Date();
    const baseDate = new Date(`${reminder.date}T${reminder.time}:00`);
    // If reminder is in the past, snooze from the current time rather than the past time
    const referenceTime = Math.max(baseDate.getTime(), now.getTime());
    const newDateTime = new Date(referenceTime + minutesToAdd * 60 * 1000);

    const yyyy = newDateTime.getFullYear();
    const mm = String(newDateTime.getMonth() + 1).padStart(2, '0');
    const dd = String(newDateTime.getDate()).padStart(2, '0');
    const hh = String(newDateTime.getHours()).padStart(2, '0');
    const min = String(newDateTime.getMinutes()).padStart(2, '0');

    triggerHaptic(40);
    onPostpone(reminder.id, `${yyyy}-${mm}-${dd}`, `${hh}:${min}`);
    onClose();
  };

  const handleTomorrowMorning = () => {
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const yyyy = tomorrow.getFullYear();
    const mm = String(tomorrow.getMonth() + 1).padStart(2, '0');
    const dd = String(tomorrow.getDate()).padStart(2, '0');

    triggerHaptic(40);
    onPostpone(reminder.id, `${yyyy}-${mm}-${dd}`, '09:00');
    onClose();
  };

  const handleCustomPostpone = () => {
    if (!customDate || !customTime) return;
    triggerHaptic(40);
    onPostpone(reminder.id, customDate, customTime);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
      <div
        className="w-full max-w-sm bg-[#0c1222] border-t sm:border border-white/10 sm:rounded-3xl rounded-t-3xl overflow-hidden shadow-2xl p-5"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/[0.08] mb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">{t.postponeOptions.title}</h3>
              <p className="text-[11px] text-slate-400 line-clamp-1">{reminder.title}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Options */}
        {!customMode ? (
          <div className="space-y-2">
            <button
              onClick={() => handleQuickPostpone(15)}
              className="w-full flex items-center justify-between p-3 rounded-2xl bg-slate-900/80 hover:bg-slate-800/80 border border-white/10 text-left transition-all active:scale-98"
            >
              <div className="flex items-center gap-2.5">
                <span className="w-2 h-2 rounded-full bg-indigo-400" />
                <span className="text-xs font-semibold text-slate-200">
                  {t.postponeOptions.m15}
                </span>
              </div>
              <span className="text-[11px] text-slate-400">Quick Snooze</span>
            </button>

            <button
              onClick={() => handleQuickPostpone(60)}
              className="w-full flex items-center justify-between p-3 rounded-2xl bg-slate-900/80 hover:bg-slate-800/80 border border-white/10 text-left transition-all active:scale-98"
            >
              <div className="flex items-center gap-2.5">
                <span className="w-2 h-2 rounded-full bg-purple-400" />
                <span className="text-xs font-semibold text-slate-200">
                  {t.postponeOptions.h1}
                </span>
              </div>
              <span className="text-[11px] text-slate-400">1 Hour</span>
            </button>

            <button
              onClick={() => handleQuickPostpone(180)}
              className="w-full flex items-center justify-between p-3 rounded-2xl bg-slate-900/80 hover:bg-slate-800/80 border border-white/10 text-left transition-all active:scale-98"
            >
              <div className="flex items-center gap-2.5">
                <span className="w-2 h-2 rounded-full bg-pink-400" />
                <span className="text-xs font-semibold text-slate-200">
                  {t.postponeOptions.h3}
                </span>
              </div>
              <span className="text-[11px] text-slate-400">3 Hours</span>
            </button>

            <button
              onClick={handleTomorrowMorning}
              className="w-full flex items-center justify-between p-3 rounded-2xl bg-slate-900/80 hover:bg-slate-800/80 border border-white/10 text-left transition-all active:scale-98"
            >
              <div className="flex items-center gap-2.5">
                <span className="w-2 h-2 rounded-full bg-amber-400" />
                <span className="text-xs font-semibold text-slate-200">
                  {t.postponeOptions.tomorrowMorning}
                </span>
              </div>
              <span className="text-[11px] text-slate-400">Tomorrow</span>
            </button>

            <button
              onClick={() => {
                setCustomDate(reminder.date);
                setCustomTime(reminder.time);
                setCustomMode(true);
              }}
              className="w-full py-2.5 text-center text-xs font-medium text-indigo-400 hover:text-indigo-300 hover:underline transition-colors"
            >
              Set Custom Date & Time
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                New Date
              </label>
              <input
                type="date"
                value={customDate}
                onChange={(e) => setCustomDate(e.target.value)}
                className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-400"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                New Time
              </label>
              <input
                type="time"
                value={customTime}
                onChange={(e) => setCustomTime(e.target.value)}
                className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-400"
              />
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setCustomMode(false)}
                className="flex-1 py-2 rounded-xl text-xs text-slate-400 hover:text-white"
              >
                Back
              </button>
              <button
                type="button"
                onClick={handleCustomPostpone}
                disabled={!customDate || !customTime}
                className="flex-1 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs disabled:opacity-50"
              >
                Apply
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
