import React, { useState } from 'react';
import {
  Sparkles,
  Bell,
  Mic,
  ShieldCheck,
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  X,
  Volume2,
  Smartphone,
} from 'lucide-react';
import { AppLanguage } from '../types/reminder';
import { triggerHaptic, playNotificationChime } from '../utils/sound';

interface OnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: AppLanguage;
  notificationPermission: NotificationPermission | 'unsupported';
  onRequestNotificationPermission: () => Promise<void>;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({
  isOpen,
  onClose,
  language,
  notificationPermission,
  onRequestNotificationPermission,
}) => {
  const [step, setStep] = useState(0);
  const [micTested, setMicTested] = useState<'idle' | 'testing' | 'granted' | 'denied'>('idle');

  if (!isOpen) return null;

  const handleNext = () => {
    triggerHaptic(20);
    if (step < 2) {
      setStep(step + 1);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    triggerHaptic(20);
    if (step > 0) setStep(step - 1);
  };

  const testMicrophoneAccess = async () => {
    setMicTested('testing');
    triggerHaptic(30);

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setMicTested('denied');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.onstart = () => {
        setMicTested('granted');
        playNotificationChime();
        recognition.stop();
      };
      recognition.onerror = () => {
        setMicTested('denied');
      };
      recognition.start();
    } catch {
      setMicTested('denied');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div
        className="w-full max-w-sm rounded-3xl bg-gradient-to-b from-[#13192f] via-[#0b1122] to-[#070b14] border border-indigo-500/30 p-6 shadow-2xl relative overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Glow Effects */}
        <div className="absolute -top-16 -right-16 w-36 h-36 bg-purple-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-36 h-36 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Progress Dots */}
        <div className="flex items-center justify-center gap-1.5 mb-6">
          {[0, 1, 2].map((idx) => (
            <span
              key={idx}
              className={`h-1.5 rounded-full transition-all ${
                step === idx
                  ? 'w-6 bg-gradient-to-r from-indigo-500 to-purple-500'
                  : 'w-1.5 bg-slate-700'
              }`}
            />
          ))}
        </div>

        {/* Slide 0: Welcome & Features */}
        {step === 0 && (
          <div className="text-center space-y-4 animate-in fade-in slide-in-from-right-4 duration-200">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 text-white flex items-center justify-center mx-auto shadow-lg shadow-indigo-600/30">
              <Sparkles className="w-7 h-7" />
            </div>

            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                Welcome to YaadMate AI
              </h2>
              <p className="text-xs text-indigo-300 font-medium mt-0.5">
                Never forget what matters most
              </p>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed text-left bg-slate-900/60 p-3.5 rounded-2xl border border-white/5 space-y-2">
              <span className="block font-semibold text-white">✨ Natural Multilingual Assistant:</span>
              Speak or type tasks in <strong className="text-indigo-300">English</strong>,{' '}
              <strong className="text-purple-300">Roman Urdu</strong> (*"Kal subah 9 baje office"*), or{' '}
              <strong className="text-pink-300">Urdu script</strong> (*"کل شام 7 بجے خریداری"*).
            </p>
          </div>
        )}

        {/* Slide 1: Notifications & Android Alarms */}
        {step === 1 && (
          <div className="text-center space-y-4 animate-in fade-in slide-in-from-right-4 duration-200">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 to-rose-500 text-white flex items-center justify-center mx-auto shadow-lg shadow-amber-500/30">
              <Bell className="w-7 h-7" />
            </div>

            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                Timely Reminder Alarms
              </h2>
              <p className="text-xs text-amber-300 font-medium mt-0.5">
                Sound, vibration & visual alerts
              </p>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed text-left bg-slate-900/60 p-3 rounded-2xl border border-white/5">
              YaadMate rings an alarm when your reminder is due. Allowing notifications ensures alerts pop up even if you are browsing another tab or app.
            </p>

            <div className="pt-1">
              {notificationPermission === 'granted' ? (
                <div className="p-2.5 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-emerald-300 text-xs font-semibold flex items-center justify-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Notifications are Active!
                </div>
              ) : (
                <button
                  onClick={onRequestNotificationPermission}
                  className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-semibold text-xs shadow-md shadow-indigo-600/30 transition-all active:scale-95 flex items-center justify-center gap-1.5"
                >
                  <Bell className="w-4 h-4" />
                  Allow Notifications
                </button>
              )}
            </div>
          </div>
        )}

        {/* Slide 2: Voice & Microphone */}
        {step === 2 && (
          <div className="text-center space-y-4 animate-in fade-in slide-in-from-right-4 duration-200">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 text-white flex items-center justify-center mx-auto shadow-lg shadow-purple-600/30">
              <Mic className="w-7 h-7" />
            </div>

            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                Hands-Free Voice Entry
              </h2>
              <p className="text-xs text-purple-300 font-medium mt-0.5">
                Speak directly in English or Urdu
              </p>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed text-left bg-slate-900/60 p-3 rounded-2xl border border-white/5">
              Tap the microphone icon in the chat or reminder creator to speak your task naturally. Microphone permission is only active while recording.
            </p>

            <div className="pt-1">
              {micTested === 'granted' ? (
                <div className="p-2.5 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-emerald-300 text-xs font-semibold flex items-center justify-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Microphone is Working!
                </div>
              ) : (
                <button
                  onClick={testMicrophoneAccess}
                  disabled={micTested === 'testing'}
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-white/10 transition-all active:scale-95 flex items-center justify-center gap-1.5"
                >
                  <Mic className="w-4 h-4 text-purple-400" />
                  {micTested === 'testing' ? 'Testing Microphone...' : 'Test Microphone Access'}
                </button>
              )}
            </div>
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="flex items-center justify-between gap-3 pt-6 mt-2 border-t border-white/10">
          {step > 0 ? (
            <button
              onClick={handlePrev}
              className="py-2 px-3 rounded-xl text-slate-400 hover:text-white text-xs font-medium flex items-center gap-1 transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
              Back
            </button>
          ) : (
            <div />
          )}

          <button
            onClick={handleNext}
            className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:to-pink-500 text-white font-semibold text-xs shadow-lg shadow-indigo-600/30 flex items-center gap-1.5 transition-all active:scale-95 ml-auto"
          >
            <span>{step === 2 ? 'Get Started' : 'Next'}</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
