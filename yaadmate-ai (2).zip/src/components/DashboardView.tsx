import React, { useState, useMemo } from 'react';
import {
  Search,
  Plus,
  Sparkles,
  Calendar,
  Clock,
  Filter,
  CheckCircle2,
  AlertCircle,
  Inbox,
  Flame,
  Mic,
} from 'lucide-react';
import { Reminder, ReminderCategory, ReminderPriority, AppLanguage } from '../types/reminder';
import { translations } from '../utils/translations';
import { ReminderCard } from './ReminderCard';
import { triggerHaptic } from '../utils/sound';

import { getLocalTodayString, isOverdue } from '../utils/dateUtils';

interface DashboardViewProps {
  reminders: Reminder[];
  language: AppLanguage;
  soundEnabled: boolean;
  vibrateEnabled: boolean;
  onToggleComplete: (id: string) => void;
  onOpenEdit: (reminder: Reminder) => void;
  onOpenPostpone: (reminder: Reminder) => void;
  onDelete: (id: string) => void;
  onOpenAddModal: () => void;
  onNavigateToChat: () => void;
  onShareToWhatsApp: (reminder: Reminder) => void;
}

type TabFilter = 'all' | 'today' | 'upcoming' | 'overdue' | ReminderCategory;

export const DashboardView: React.FC<DashboardViewProps> = ({
  reminders,
  language,
  soundEnabled,
  vibrateEnabled,
  onToggleComplete,
  onOpenEdit,
  onOpenPostpone,
  onDelete,
  onOpenAddModal,
  onNavigateToChat,
  onShareToWhatsApp,
}) => {
  const t = translations[language];

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<TabFilter>('all');
  const [priorityFilter, setPriorityFilter] = useState<'all' | ReminderPriority>('all');

  // Stats calculation using local timezone
  const stats = useMemo(() => {
    const now = new Date();
    const todayStr = getLocalTodayString(now);

    const active = reminders.filter((r) => !r.completed);
    const completed = reminders.filter((r) => r.completed);

    const today = active.filter((r) => r.date === todayStr);
    const overdue = active.filter((r) => isOverdue(r.date, r.time, now));
    const urgentCount = active.filter((r) => r.priority === 'urgent').length;

    return {
      activeCount: active.length,
      todayCount: today.length,
      overdueCount: overdue.length,
      completedCount: completed.length,
      urgentCount,
    };
  }, [reminders]);

  // Filtered Reminders
  const filteredReminders = useMemo(() => {
    const now = new Date();
    const todayStr = getLocalTodayString(now);

    return reminders
      .filter((r) => {
        // Exclude completed in main dashboard unless user specifically chooses 'all' and no active
        if (r.completed) return false;

        // Search text matching
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchTitle = r.title.toLowerCase().includes(q);
          const matchDesc = r.description.toLowerCase().includes(q);
          const matchCat = r.category.toLowerCase().includes(q);
          if (!matchTitle && !matchDesc && !matchCat) return false;
        }

        // Priority filter
        if (priorityFilter !== 'all' && r.priority !== priorityFilter) {
          return false;
        }

        // Tab category / time filter
        if (selectedFilter === 'all') return true;
        if (selectedFilter === 'today') return r.date === todayStr;
        if (selectedFilter === 'upcoming') {
          return r.date > todayStr;
        }
        if (selectedFilter === 'overdue') {
          return isOverdue(r.date, r.time, now);
        }

        return r.category === selectedFilter;
      })
      .sort((a, b) => {
        // Sort: Urgent & Overdue first, then by chronological datetime
        const dtA = new Date(`${a.date}T${a.time}:00`).getTime();
        const dtB = new Date(`${b.date}T${b.time}:00`).getTime();

        const priorityWeights: Record<ReminderPriority, number> = {
          urgent: 4,
          high: 3,
          medium: 2,
          low: 1,
        };

        if (a.priority === 'urgent' && b.priority !== 'urgent') return -1;
        if (b.priority === 'urgent' && a.priority !== 'urgent') return 1;

        return dtA - dtB;
      });
  }, [reminders, searchQuery, selectedFilter, priorityFilter]);

  const categories: ReminderCategory[] = [
    'Work',
    'Personal',
    'Health',
    'Shopping',
    'Meeting',
    'Important',
    'Finance',
  ];

  return (
    <div className="p-4 space-y-4 max-w-lg mx-auto pb-28">
      {/* Search & AI Quick Ask Bar */}
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.actions.search}
            className="w-full bg-[#0c1222] border border-white/10 rounded-2xl pl-10 pr-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-400 transition-colors shadow-sm"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
            >
              ×
            </button>
          )}
        </div>

        {/* AI Chat Shortcut */}
        <button
          onClick={onNavigateToChat}
          title="Open AI Reminder Chat"
          className="flex items-center gap-1.5 px-3 py-2.5 rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-semibold text-xs shadow-md shadow-indigo-600/30 transition-all active:scale-95 shrink-0"
        >
          <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
          <span>Ask AI</span>
        </button>
      </div>

      {/* Quick Metrics Carousel */}
      <div className="grid grid-cols-4 gap-2">
        {/* Today */}
        <button
          onClick={() => {
            setSelectedFilter('today');
            triggerHaptic(20);
          }}
          className={`p-2.5 rounded-2xl border text-left transition-all active:scale-95 ${
            selectedFilter === 'today'
              ? 'bg-indigo-600/30 border-indigo-400 shadow-md shadow-indigo-600/20'
              : 'bg-[#0c1222] border-white/[0.08] hover:border-white/20'
          }`}
        >
          <span className="text-[10px] text-slate-400 font-medium block">{t.stats.today}</span>
          <span className="text-base font-extrabold text-white mt-0.5 block">
            {stats.todayCount}
          </span>
        </button>

        {/* Overdue */}
        <button
          onClick={() => {
            setSelectedFilter('overdue');
            triggerHaptic(20);
          }}
          className={`p-2.5 rounded-2xl border text-left transition-all active:scale-95 ${
            selectedFilter === 'overdue'
              ? 'bg-rose-500/25 border-rose-400 shadow-md shadow-rose-500/20'
              : 'bg-[#0c1222] border-white/[0.08] hover:border-white/20'
          }`}
        >
          <span className="text-[10px] text-rose-300 font-medium block flex items-center gap-1">
            {stats.overdueCount > 0 && <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" />}
            {t.stats.overdue}
          </span>
          <span className="text-base font-extrabold text-rose-400 mt-0.5 block">
            {stats.overdueCount}
          </span>
        </button>

        {/* Upcoming */}
        <button
          onClick={() => {
            setSelectedFilter('upcoming');
            triggerHaptic(20);
          }}
          className={`p-2.5 rounded-2xl border text-left transition-all active:scale-95 ${
            selectedFilter === 'upcoming'
              ? 'bg-purple-600/30 border-purple-400 shadow-md shadow-purple-600/20'
              : 'bg-[#0c1222] border-white/[0.08] hover:border-white/20'
          }`}
        >
          <span className="text-[10px] text-slate-400 font-medium block">{t.stats.upcoming}</span>
          <span className="text-base font-extrabold text-purple-300 mt-0.5 block">
            {stats.activeCount - stats.todayCount - stats.overdueCount < 0
              ? 0
              : stats.activeCount - stats.todayCount}
          </span>
        </button>

        {/* Total Active */}
        <button
          onClick={() => {
            setSelectedFilter('all');
            triggerHaptic(20);
          }}
          className={`p-2.5 rounded-2xl border text-left transition-all active:scale-95 ${
            selectedFilter === 'all'
              ? 'bg-slate-800 border-indigo-400'
              : 'bg-[#0c1222] border-white/[0.08] hover:border-white/20'
          }`}
        >
          <span className="text-[10px] text-slate-400 font-medium block">All Active</span>
          <span className="text-base font-extrabold text-indigo-300 mt-0.5 block">
            {stats.activeCount}
          </span>
        </button>
      </div>

      {/* Filter Chips Bar (All, Today, Categories) */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
        <button
          onClick={() => {
            setSelectedFilter('all');
            triggerHaptic(20);
          }}
          className={`px-3 py-1.5 rounded-xl font-medium shrink-0 transition-all active:scale-95 border ${
            selectedFilter === 'all'
              ? 'bg-indigo-600 text-white border-indigo-500 shadow-sm shadow-indigo-600/30'
              : 'bg-[#0c1222] text-slate-300 border-white/10 hover:border-white/20'
          }`}
        >
          {t.actions.all}
        </button>

        <button
          onClick={() => {
            setSelectedFilter('today');
            triggerHaptic(20);
          }}
          className={`px-3 py-1.5 rounded-xl font-medium shrink-0 transition-all active:scale-95 border ${
            selectedFilter === 'today'
              ? 'bg-indigo-600 text-white border-indigo-500 shadow-sm shadow-indigo-600/30'
              : 'bg-[#0c1222] text-slate-300 border-white/10 hover:border-white/20'
          }`}
        >
          {t.stats.today} ({stats.todayCount})
        </button>

        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => {
              setSelectedFilter(cat);
              triggerHaptic(20);
            }}
            className={`px-3 py-1.5 rounded-xl font-medium shrink-0 transition-all active:scale-95 border ${
              selectedFilter === cat
                ? 'bg-indigo-600 text-white border-indigo-500 shadow-sm shadow-indigo-600/30'
                : 'bg-[#0c1222] text-slate-300 border-white/10 hover:border-white/20'
            }`}
          >
            {t.categories[cat]}
          </button>
        ))}
      </div>

      {/* Priority Filter Strip (Optional refinement) */}
      <div className="flex items-center justify-between text-xs px-1">
        <span className="text-[11px] font-semibold text-slate-400">
          Showing {filteredReminders.length} reminder{filteredReminders.length !== 1 ? 's' : ''}
        </span>

        {/* Priority quick filter dropdown / pill */}
        <div className="flex items-center gap-1">
          <span className="text-[10px] text-slate-500">Priority:</span>
          {(['all', 'urgent', 'high'] as const).map((p) => (
            <button
              key={p}
              onClick={() => {
                setPriorityFilter(p);
                triggerHaptic(20);
              }}
              className={`px-2 py-0.5 rounded-md text-[10px] font-medium uppercase transition-colors ${
                priorityFilter === p
                  ? p === 'urgent'
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                    : p === 'high'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Reminder Cards List */}
      {filteredReminders.length === 0 ? (
        <div className="text-center py-12 px-4 rounded-3xl bg-[#0c1222]/60 border border-white/[0.04]">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center mx-auto mb-3 border border-indigo-500/20">
            <Inbox className="w-6 h-6" />
          </div>
          <h4 className="text-sm font-semibold text-white mb-1">
            {searchQuery ? 'No matching reminders found' : 'No active reminders in this view'}
          </h4>
          <p className="text-xs text-slate-400 max-w-xs mx-auto mb-4">
            {searchQuery
              ? 'Try modifying your search keywords or clear filters.'
              : 'Keep your day organized by adding a new task or speaking to your AI Assistant.'}
          </p>

          <div className="flex items-center justify-center gap-2">
            <button
              onClick={onOpenAddModal}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition-all active:scale-95 flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              {t.actions.addReminder}
            </button>

            <button
              onClick={onNavigateToChat}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-all active:scale-95 flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              Speak to AI
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredReminders.map((reminder) => (
            <ReminderCard
              key={reminder.id}
              reminder={reminder}
              language={language}
              soundEnabled={soundEnabled}
              vibrateEnabled={vibrateEnabled}
              onToggleComplete={onToggleComplete}
              onOpenEdit={onOpenEdit}
              onOpenPostpone={onOpenPostpone}
              onDelete={onDelete}
              onShareToWhatsApp={onShareToWhatsApp}
            />
          ))}
        </div>
      )}
    </div>
  );
};
