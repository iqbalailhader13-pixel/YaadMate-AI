import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  Mic,
  MicOff,
  Calendar,
  Clock,
  Tag,
  Flag,
  Repeat,
  AlertCircle,
  Loader2,
  Check,
} from 'lucide-react';
import {
  Reminder,
  ReminderCategory,
  ReminderPriority,
  ReminderRecurrence,
  AppLanguage,
} from '../types/reminder';
import { translations } from '../utils/translations';
import { triggerHaptic } from '../utils/sound';

interface ReminderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (reminderData: Omit<Reminder, 'id' | 'createdAt' | 'completed' | 'postponeCount'>) => void;
  initialReminder?: Reminder | null;
  language: AppLanguage;
}

export const ReminderModal: React.FC<ReminderModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialReminder,
  language,
}) => {
  const t = translations[language];

  // Form State
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [category, setCategory] = useState<ReminderCategory>('Personal');
  const [priority, setPriority] = useState<ReminderPriority>('medium');
  const [recurrence, setRecurrence] = useState<ReminderRecurrence>('none');

  // Quick NL / AI state
  const [naturalInput, setNaturalInput] = useState('');
  const [isParsingNL, setIsParsingNL] = useState(false);
  const [nlNotice, setNlNotice] = useState<string | null>(null);

  // Voice recording state
  const [isListening, setIsListening] = useState(false);
  const [speechError, setSpeechError] = useState<string | null>(null);

  // Validation errors
  const [errors, setErrors] = useState<{ title?: string; date?: string; time?: string }>({});

  // Populate state on open or initialReminder change
  useEffect(() => {
    if (initialReminder) {
      setTitle(initialReminder.title);
      setDescription(initialReminder.description || '');
      setDate(initialReminder.date);
      setTime(initialReminder.time);
      setCategory(initialReminder.category);
      setPriority(initialReminder.priority);
      setRecurrence(initialReminder.recurrence);
    } else {
      // Default to today + current time + 30 mins
      const now = new Date();
      now.setMinutes(now.getMinutes() + 30);
      const yyyy = now.getFullYear();
      const mm = String(now.getMonth() + 1).padStart(2, '0');
      const dd = String(now.getDate()).padStart(2, '0');
      const hh = String(now.getHours()).padStart(2, '0');
      const min = String(Math.floor(now.getMinutes() / 5) * 5).padStart(2, '0');

      setTitle('');
      setDescription('');
      setDate(`${yyyy}-${mm}-${dd}`);
      setTime(`${hh}:${min}`);
      setCategory('Personal');
      setPriority('medium');
      setRecurrence('none');
    }
    setNaturalInput('');
    setNlNotice(null);
    setErrors({});
  }, [initialReminder, isOpen]);

  if (!isOpen) return null;

  // Handle Quick NL parse
  const handleParseNaturalLanguage = async (textToParse?: string) => {
    const query = (textToParse || naturalInput).trim();
    if (!query) return;

    setIsParsingNL(true);
    setNlNotice(null);

    try {
      const response = await fetch('/api/gemini/parse-reminder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: query,
          currentDateTime: new Date().toISOString(),
        }),
      });

      const data = await response.json();
      if (data.title) setTitle(data.title);
      if (data.description) setDescription(data.description);
      if (data.date) setDate(data.date);
      if (data.time) setTime(data.time);
      if (data.category) setCategory(data.category);
      if (data.priority) setPriority(data.priority);
      if (data.recurrence) setRecurrence(data.recurrence);

      setNlNotice(data.explanation || 'Details extracted successfully!');
      triggerHaptic(50);
    } catch (err) {
      console.error('Failed to parse natural language:', err);
      setNlNotice('Could not connect to parsing service. Please fill fields manually.');
    } finally {
      setIsParsingNL(false);
    }
  };

  // Voice speech-to-text handler
  const handleToggleVoice = () => {
    setSpeechError(null);

    if (isListening) {
      setIsListening(false);
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setSpeechError('Voice speech recognition is not supported in this browser.');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = language === 'ur' ? 'ur-PK' : 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
        triggerHaptic(30);
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          setNaturalInput(transcript);
          handleParseNaturalLanguage(transcript);
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        const msg =
          event.error === 'not-allowed' || event.error === 'permission-denied'
            ? 'Microphone permission denied. Allow microphone in your browser settings or type.'
            : event.error === 'no-speech'
            ? 'No speech detected. Please try speaking again.'
            : `Voice error (${event.error}). You can type your request directly.`;
        setSpeechError(msg);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch (err) {
      console.error('Failed to start speech recognition:', err);
      setSpeechError('Microphone permission denied or unavailable.');
      setIsListening(false);
    }
  };

  // Form submission with validation
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: { title?: string; date?: string; time?: string } = {};

    if (!title.trim()) {
      newErrors.title = 'Please enter a reminder title.';
    }

    if (!date) {
      newErrors.date = 'Please pick a valid date.';
    }

    if (!time) {
      newErrors.time = 'Please pick a valid time.';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      triggerHaptic([60, 40, 60]);
      return;
    }

    onSave({
      title: title.trim(),
      description: description.trim(),
      date,
      time,
      category,
      priority,
      recurrence,
    });
    triggerHaptic(40);
    onClose();
  };

  const categories: ReminderCategory[] = [
    'Work',
    'Personal',
    'Health',
    'Shopping',
    'Meeting',
    'Important',
    'Finance',
  ];

  const priorities: ReminderPriority[] = ['low', 'medium', 'high', 'urgent'];

  const recurrences: ReminderRecurrence[] = [
    'none',
    'daily',
    'weekly',
    'weekdays',
    'monthly',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-lg bg-[#0c1222] border-t sm:border border-white/10 sm:rounded-3xl rounded-t-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/[0.08] bg-[#090e1a]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-base text-white">
                {initialReminder ? t.actions.edit : t.actions.addReminder}
              </h2>
              <p className="text-[11px] text-slate-400">
                {initialReminder ? 'Modify reminder details' : 'AI-assisted or manual schedule'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto p-5 space-y-4">
          {/* Quick AI Voice / Text Smart Bar (shown primarily when adding new) */}
          {!initialReminder && (
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-indigo-950/60 via-purple-950/40 to-slate-900 border border-indigo-500/30">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-indigo-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                  Quick Fill with Natural Voice or Text
                </span>
                <span className="text-[10px] text-slate-400">English / Roman Urdu</span>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={naturalInput}
                  onChange={(e) => setNaturalInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleParseNaturalLanguage()}
                  placeholder='e.g. "Kal shaam 7 baje grocery lena" or "Doctor tomorrow 4pm"'
                  className="flex-1 bg-slate-900/90 border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-400"
                />

                {/* Voice button */}
                <button
                  type="button"
                  onClick={handleToggleVoice}
                  title="Voice input"
                  className={`p-2 rounded-xl border transition-all active:scale-95 ${
                    isListening
                      ? 'bg-rose-500 border-rose-400 text-white animate-pulse'
                      : 'bg-slate-800 border-white/10 text-slate-300 hover:text-white'
                  }`}
                >
                  {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                </button>

                {/* AI Parse button */}
                <button
                  type="button"
                  onClick={() => handleParseNaturalLanguage()}
                  disabled={isParsingNL || !naturalInput.trim()}
                  className="px-3 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-medium text-xs flex items-center gap-1 shadow-md shadow-indigo-600/30 disabled:opacity-50 transition-all active:scale-95"
                >
                  {isParsingNL ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    'Fill'
                  )}
                </button>
              </div>

              {isListening && (
                <div className="flex items-center gap-2 mt-2 text-xs text-rose-300">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
                  </span>
                  <span>{t.chat.voiceListening}</span>
                </div>
              )}

              {speechError && (
                <p className="text-[11px] text-amber-300 mt-1.5 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3 shrink-0" />
                  {speechError}
                </p>
              )}

              {nlNotice && (
                <p className="text-[11px] text-emerald-300 mt-1.5 flex items-center gap-1 font-medium bg-emerald-950/40 p-1.5 rounded-lg border border-emerald-500/20">
                  <Check className="w-3.5 h-3.5 shrink-0 text-emerald-400" />
                  {nlNotice}
                </p>
              )}
            </div>
          )}

          {/* Form Inputs */}
          <form id="reminder-form" onSubmit={handleSubmit} className="space-y-4">
            {/* Title */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {t.fields.title} <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => {
                  setTitle(e.target.value);
                  if (errors.title) setErrors({ ...errors, title: undefined });
                }}
                placeholder={t.fields.placeholderTitle}
                className={`w-full bg-slate-900/90 border rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none transition-colors ${
                  errors.title
                    ? 'border-rose-500 focus:border-rose-500'
                    : 'border-white/10 focus:border-indigo-400'
                }`}
              />
              {errors.title && (
                <p className="text-[11px] text-rose-400 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  {errors.title}
                </p>
              )}
            </div>

            {/* Date & Time Row */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                  {t.fields.date} <span className="text-rose-400">*</span>
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => {
                    setDate(e.target.value);
                    if (errors.date) setErrors({ ...errors, date: undefined });
                  }}
                  className={`w-full bg-slate-900/90 border rounded-xl px-3 py-2 text-xs text-white focus:outline-none transition-colors ${
                    errors.date
                      ? 'border-rose-500 focus:border-rose-500'
                      : 'border-white/10 focus:border-indigo-400'
                  }`}
                />
                {errors.date && (
                  <p className="text-[10px] text-rose-400 mt-1">{errors.date}</p>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-indigo-400" />
                  {t.fields.time} <span className="text-rose-400">*</span>
                </label>
                <input
                  type="time"
                  value={time}
                  onChange={(e) => {
                    setTime(e.target.value);
                    if (errors.time) setErrors({ ...errors, time: undefined });
                  }}
                  className={`w-full bg-slate-900/90 border rounded-xl px-3 py-2 text-xs text-white focus:outline-none transition-colors ${
                    errors.time
                      ? 'border-rose-500 focus:border-rose-500'
                      : 'border-white/10 focus:border-indigo-400'
                  }`}
                />
                {errors.time && (
                  <p className="text-[10px] text-rose-400 mt-1">{errors.time}</p>
                )}
              </div>
            </div>

            {/* Category Select Chips */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
                <Tag className="w-3.5 h-3.5 text-indigo-400" />
                {t.fields.category}
              </label>
              <div className="flex flex-wrap gap-1.5">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setCategory(cat)}
                    className={`px-2.5 py-1.5 rounded-xl text-xs font-medium border transition-all active:scale-95 ${
                      category === cat
                        ? 'bg-indigo-600 text-white border-indigo-500 shadow-sm shadow-indigo-600/30'
                        : 'bg-slate-900/60 text-slate-300 border-white/10 hover:border-white/20'
                    }`}
                  >
                    {t.categories[cat]}
                  </button>
                ))}
              </div>
            </div>

            {/* Priority Select Chips */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
                <Flag className="w-3.5 h-3.5 text-indigo-400" />
                {t.fields.priority}
              </label>
              <div className="grid grid-cols-4 gap-1.5">
                {priorities.map((p) => {
                  const isSelected = priority === p;
                  let colorClass = 'border-white/10 text-slate-300 bg-slate-900/60';
                  if (isSelected) {
                    if (p === 'urgent')
                      colorClass = 'bg-rose-500/20 text-rose-300 border-rose-500 font-bold';
                    else if (p === 'high')
                      colorClass = 'bg-amber-500/20 text-amber-300 border-amber-500 font-bold';
                    else if (p === 'medium')
                      colorClass = 'bg-indigo-500/20 text-indigo-300 border-indigo-500 font-bold';
                    else
                      colorClass = 'bg-slate-700/40 text-slate-200 border-slate-500 font-bold';
                  }

                  return (
                    <button
                      key={p}
                      type="button"
                      onClick={() => setPriority(p)}
                      className={`py-1.5 rounded-xl text-xs border text-center transition-all capitalize active:scale-95 ${colorClass}`}
                    >
                      {t.priorities[p]}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Recurrence Select Chips */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
                <Repeat className="w-3.5 h-3.5 text-indigo-400" />
                {t.fields.recurrence}
              </label>
              <div className="flex flex-wrap gap-1.5">
                {recurrences.map((rec) => (
                  <button
                    key={rec}
                    type="button"
                    onClick={() => setRecurrence(rec)}
                    className={`px-2.5 py-1 rounded-xl text-xs font-medium border transition-all active:scale-95 ${
                      recurrence === rec
                        ? 'bg-purple-600/30 text-purple-200 border-purple-500 font-bold'
                        : 'bg-slate-900/60 text-slate-400 border-white/10 hover:border-white/20'
                    }`}
                  >
                    {t.recurrences[rec]}
                  </button>
                ))}
              </div>
            </div>

            {/* Notes / Description */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {t.fields.description}
              </label>
              <textarea
                rows={2}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder={t.fields.placeholderDesc}
                className="w-full bg-slate-900/90 border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-400"
              />
            </div>
          </form>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-2 px-5 py-3.5 border-t border-white/[0.08] bg-[#090e1a]">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-medium text-slate-300 hover:bg-slate-800 transition-colors"
          >
            {t.actions.cancel}
          </button>
          <button
            type="submit"
            form="reminder-form"
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:to-pink-500 text-white text-xs font-semibold shadow-lg shadow-indigo-600/30 transition-all active:scale-95 flex items-center gap-1.5"
          >
            <Check className="w-3.5 h-3.5 stroke-[2.5]" />
            {t.actions.save}
          </button>
        </div>
      </div>
    </div>
  );
};
