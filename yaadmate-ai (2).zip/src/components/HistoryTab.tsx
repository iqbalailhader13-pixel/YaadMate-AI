import React from 'react';
import {
  CheckCircle2,
  Trash2,
  RotateCcw,
  Award,
  TrendingUp,
  Calendar,
  Clock,
  Sparkles,
} from 'lucide-react';
import { Reminder, AppLanguage } from '../types/reminder';
import { translations } from '../utils/translations';
import { triggerHaptic } from '../utils/sound';

interface HistoryTabProps {
  reminders: Reminder[];
  onToggleComplete: (id: string) => void;
  onDelete: (id: string) => void;
  onClearCompleted: () => void;
  language: AppLanguage;
}

export const HistoryTab: React.FC<HistoryTabProps> = ({
  reminders,
  onToggleComplete,
  onDelete,
  onClearCompleted,
  language,
}) => {
  const t = translations[language];
  const [confirmClear, setConfirmClear] = React.useState(false);

  const completedReminders = reminders.filter((r) => r.completed);
  const totalCount = reminders.length;
  const completionRate =
    totalCount > 0 ? Math.round((completedReminders.length / totalCount) * 100) : 0;

  return (
    <div className="p-4 space-y-4 max-w-lg mx-auto pb-24">
      {/* Overview Stat Card */}
      <div className="p-4 rounded-3xl bg-gradient-to-br from-indigo-950/70 via-purple-950/40 to-slate-900 border border-indigo-500/30 shadow-xl">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-sm text-white">Productivity Score</h2>
              <p className="text-[11px] text-slate-400">Completed tasks overview</p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xl font-extrabold text-emerald-400">{completionRate}%</span>
            <p className="text-[10px] text-slate-400">Completion rate</p>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden mb-3">
          <div
            className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-500 rounded-full"
            style={{ width: `${completionRate}%` }}
          />
        </div>

        <div className="grid grid-cols-2 gap-2 text-center text-xs">
          <div className="p-2 rounded-xl bg-slate-900/60 border border-white/5">
            <span className="font-bold text-white text-base">{completedReminders.length}</span>
            <p className="text-[10px] text-slate-400">{t.stats.completed}</p>
          </div>
          <div className="p-2 rounded-xl bg-slate-900/60 border border-white/5">
            <span className="font-bold text-indigo-300 text-base">
              {reminders.filter((r) => !r.completed).length}
            </span>
            <p className="text-[10px] text-slate-400">{t.stats.today} Active</p>
          </div>
        </div>
      </div>

      {/* Header Row with Clear Button */}
      <div className="flex items-center justify-between px-1">
        <h3 className="font-bold text-xs uppercase tracking-wider text-slate-400">
          Completed Reminders ({completedReminders.length})
        </h3>

        {completedReminders.length > 0 && (
          confirmClear ? (
            <div className="flex items-center gap-2 animate-in fade-in">
              <button
                onClick={() => {
                  triggerHaptic(50);
                  onClearCompleted();
                  setConfirmClear(false);
                }}
                className="text-[11px] bg-rose-600 hover:bg-rose-500 text-white font-semibold px-2.5 py-1 rounded-lg transition-colors"
              >
                Yes, clear all
              </button>
              <button
                onClick={() => setConfirmClear(false)}
                className="text-[11px] text-slate-400 hover:text-white px-2 py-1"
              >
                Cancel
              </button>
            </div>
          ) : (
            <button
              onClick={() => {
                triggerHaptic(30);
                setConfirmClear(true);
              }}
              className="text-[11px] text-rose-400 hover:text-rose-300 font-medium flex items-center gap-1 transition-colors"
            >
              <Trash2 className="w-3 h-3" />
              {t.actions.clearCompleted}
            </button>
          )
        )}
      </div>

      {/* Reminders List or Empty State */}
      {completedReminders.length === 0 ? (
        <div className="text-center py-12 px-4 rounded-3xl bg-slate-900/40 border border-white/[0.04]">
          <div className="w-12 h-12 rounded-2xl bg-slate-800 text-slate-400 flex items-center justify-center mx-auto mb-3">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <h4 className="text-sm font-semibold text-white mb-1">No completed reminders yet</h4>
          <p className="text-xs text-slate-400 max-w-xs mx-auto">
            When you complete tasks on your dashboard, they will appear here as part of your productivity record.
          </p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {completedReminders.map((reminder) => (
            <div
              key={reminder.id}
              className="p-3.5 rounded-2xl bg-[#0c1322] border border-white/[0.06] flex items-center justify-between gap-3"
            >
              <div className="flex items-start gap-3 min-w-0">
                <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5 border border-emerald-500/40">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                </div>
                <div className="min-w-0">
                  <h4 className="text-xs font-semibold text-slate-300 line-through truncate">
                    {reminder.title}
                  </h4>
                  <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-400">
                    <span className="flex items-center gap-0.5">
                      <Calendar className="w-2.5 h-2.5" />
                      {reminder.date}
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-0.5">
                      <Clock className="w-2.5 h-2.5" />
                      {reminder.time}
                    </span>
                    <span>•</span>
                    <span className="text-indigo-400">{reminder.category}</span>
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={() => {
                    triggerHaptic(30);
                    onToggleComplete(reminder.id);
                  }}
                  title="Restore to active reminders"
                  className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-300 hover:bg-slate-800 transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => {
                    triggerHaptic(30);
                    onDelete(reminder.id);
                  }}
                  title={t.actions.delete}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
