import React, { useState } from 'react';
import {
  MessageSquare,
  Send,
  ShieldAlert,
  Info,
  CheckCircle2,
  Copy,
  Clock,
  Sparkles,
  Terminal,
  Code2,
  Server,
  Layers,
} from 'lucide-react';
import { Reminder, AppLanguage } from '../types/reminder';
import { translations } from '../utils/translations';
import { triggerHaptic } from '../utils/sound';

interface WhatsAppTabProps {
  reminders: Reminder[];
  language: AppLanguage;
}

export const WhatsAppTab: React.FC<WhatsAppTabProps> = ({ reminders, language }) => {
  const t = translations[language];

  const activeReminders = reminders.filter((r) => !r.completed);
  const [selectedReminderId, setSelectedReminderId] = useState<string>(
    activeReminders[0]?.id || ''
  );
  const [customPhone, setCustomPhone] = useState('');
  const [copied, setCopied] = useState(false);
  const [copiedCurl, setCopiedCurl] = useState(false);
  const [activeSubTab, setActiveSubTab] = useState<'dispatch' | 'business_api'>('dispatch');

  // Cloud API Mock / Config inputs
  const [phoneNumberId, setPhoneNumberId] = useState('109283746501928');
  const [templateName, setTemplateName] = useState('yaadmate_reminder_alert');

  const selectedReminder = reminders.find((r) => r.id === selectedReminderId) || activeReminders[0];

  // Format message text for personal WhatsApp click-to-chat
  const generateMessageText = (r?: Reminder) => {
    if (!r) return '';
    return `*🔔 YaadMate AI Reminder*\n\n📌 *Task:* ${r.title}\n📅 *Date:* ${r.date}\n⏰ *Time:* ${r.time}\n🏷️ *Category:* ${r.category}\n⚡ *Priority:* ${r.priority.toUpperCase()}${
      r.description ? `\n📝 *Notes:* ${r.description}` : ''
    }\n\n_Sent via YaadMate AI_`;
  };

  // Generate official Meta WhatsApp Business Cloud API JSON payload
  const generateCloudApiPayload = (r?: Reminder) => {
    const cleanPhone = customPhone.replace(/[^0-9]/g, '') || '923001234567';
    return {
      messaging_product: 'whatsapp',
      recipient_type: 'individual',
      to: cleanPhone,
      type: 'template',
      template: {
        name: templateName,
        language: { code: 'en_US' },
        components: [
          {
            type: 'body',
            parameters: [
              { type: 'text', text: r?.title || 'Team Task' },
              { type: 'text', text: `${r?.date || 'Today'} at ${r?.time || '09:00'}` },
              { type: 'text', text: r?.priority?.toUpperCase() || 'MEDIUM' },
              { type: 'text', text: r?.description || 'No additional notes' },
            ],
          },
        ],
      },
    };
  };

  const generateCurlCommand = () => {
    const payload = JSON.stringify(generateCloudApiPayload(selectedReminder), null, 2);
    return `curl -X POST "https://graph.facebook.com/v18.0/${phoneNumberId}/messages" \\
  -H "Authorization: Bearer YOUR_META_SYSTEM_USER_ACCESS_TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '${payload}'`;
  };

  const handleSendToWhatsApp = () => {
    if (!selectedReminder) return;

    triggerHaptic(40);
    const text = generateMessageText(selectedReminder);
    const encodedText = encodeURIComponent(text);

    let url = `https://wa.me/?text=${encodedText}`;
    if (customPhone.trim()) {
      const cleanPhone = customPhone.replace(/[^0-9]/g, '');
      url = `https://wa.me/${cleanPhone}?text=${encodedText}`;
    }

    try {
      const link = document.createElement('a');
      link.href = url;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch {
      navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleCopyText = () => {
    if (!selectedReminder) return;
    const text = generateMessageText(selectedReminder);
    navigator.clipboard.writeText(text);
    triggerHaptic(30);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCopyCurl = () => {
    const curl = generateCurlCommand();
    navigator.clipboard.writeText(curl);
    triggerHaptic(30);
    setCopiedCurl(true);
    setTimeout(() => setCopiedCurl(false), 2000);
  };

  return (
    <div className="p-4 space-y-4 max-w-lg mx-auto pb-24 text-xs">
      {/* Header Info Banner */}
      <div className="p-4 rounded-3xl bg-gradient-to-br from-emerald-950/60 via-slate-900 to-[#070b14] border border-emerald-500/30 shadow-xl">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30 shrink-0">
            <MessageSquare className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-bold text-sm text-white">WhatsApp Integration Hub</h2>
            <p className="text-[11px] text-slate-300">Personal click-to-chat & Official Cloud API</p>
          </div>
        </div>

        {/* Sub-tab Navigation */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-900/80 rounded-xl border border-white/10 mt-3">
          <button
            onClick={() => {
              setActiveSubTab('dispatch');
              triggerHaptic(20);
            }}
            className={`flex-1 py-1.5 rounded-lg text-center font-semibold transition-all ${
              activeSubTab === 'dispatch'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Quick Send (wa.me)
          </button>
          <button
            onClick={() => {
              setActiveSubTab('business_api');
              triggerHaptic(20);
            }}
            className={`flex-1 py-1.5 rounded-lg text-center font-semibold transition-all ${
              activeSubTab === 'business_api'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Meta Cloud API Spec
          </button>
        </div>
      </div>

      {/* Subtab 1: Quick Personal WhatsApp Dispatch */}
      {activeSubTab === 'dispatch' && (
        <div className="p-4 rounded-3xl bg-[#0d1527] border border-white/10 space-y-3.5 animate-in fade-in">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            Send Reminder to WhatsApp
          </h3>

          {activeReminders.length === 0 ? (
            <p className="text-xs text-slate-400">
              You have no active pending reminders. Create a reminder on the Dashboard first.
            </p>
          ) : (
            <>
              <div>
                <label className="block font-medium text-slate-300 mb-1">
                  Select Reminder
                </label>
                <select
                  value={selectedReminderId}
                  onChange={(e) => setSelectedReminderId(e.target.value)}
                  className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-400"
                >
                  {activeReminders.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.title} — {r.date} ({r.time})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-300 mb-1">
                  Recipient Phone Number (Optional)
                </label>
                <input
                  type="tel"
                  value={customPhone}
                  onChange={(e) => setCustomPhone(e.target.value)}
                  placeholder="e.g. 923001234567 or leave blank"
                  className="w-full bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  Include country code (e.g. 92 for Pakistan). Leave empty to choose contact in WhatsApp.
                </span>
              </div>

              {selectedReminder && (
                <div className="p-3 rounded-xl bg-slate-900/90 border border-white/5 space-y-1.5">
                  <span className="text-[10px] uppercase font-bold text-slate-400">
                    Message Preview
                  </span>
                  <pre className="text-[11px] text-emerald-300 whitespace-pre-wrap font-sans bg-[#070b14] p-2.5 rounded-lg border border-white/5">
                    {generateMessageText(selectedReminder)}
                  </pre>
                </div>
              )}

              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleCopyText}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium border border-white/10 transition-colors flex items-center justify-center gap-1.5"
                >
                  {copied ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      Copy Text
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={handleSendToWhatsApp}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold shadow-lg shadow-emerald-600/30 transition-all active:scale-95 flex items-center justify-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  Open in WhatsApp
                </button>
              </div>
            </>
          )}
        </div>
      )}

      {/* Subtab 2: Official Meta Cloud API Architecture */}
      {activeSubTab === 'business_api' && (
        <div className="space-y-3.5 animate-in fade-in">
          {/* Architecture Card */}
          <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-emerald-500/25 flex items-start gap-3">
            <Server className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h4 className="font-semibold text-emerald-300">
                Official Meta WhatsApp Cloud API Architecture
              </h4>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                For automated 24/7 background delivery (when the user’s phone or browser is offline), Meta requires using the official WhatsApp Business Platform. Messages are dispatched via registered, pre-approved notification templates.
              </p>
            </div>
          </div>

          {/* Interactive Cloud API Payload & cURL Generator */}
          <div className="p-4 rounded-3xl bg-[#0d1527] border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                <Code2 className="w-4 h-4 text-indigo-400" />
                Live Cloud API Payload
              </h4>
              <button
                onClick={handleCopyCurl}
                className="text-[11px] text-emerald-400 hover:underline flex items-center gap-1 font-semibold"
              >
                {copiedCurl ? (
                  <>
                    <CheckCircle2 className="w-3 h-3" />
                    cURL Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    Copy cURL Command
                  </>
                )}
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[10px] text-slate-400 mb-0.5">
                  Phone Number ID
                </label>
                <input
                  type="text"
                  value={phoneNumberId}
                  onChange={(e) => setPhoneNumberId(e.target.value)}
                  className="w-full bg-slate-900 border border-white/10 rounded-lg px-2.5 py-1.5 text-[11px] text-white"
                />
              </div>

              <div>
                <label className="block text-[10px] text-slate-400 mb-0.5">
                  Template Name
                </label>
                <input
                  type="text"
                  value={templateName}
                  onChange={(e) => setTemplateName(e.target.value)}
                  className="w-full bg-slate-900 border border-white/10 rounded-lg px-2.5 py-1.5 text-[11px] text-white"
                />
              </div>
            </div>

            <div className="rounded-xl bg-[#050811] p-3 border border-white/5 overflow-x-auto">
              <pre className="text-[11px] text-emerald-300 font-mono">
                {JSON.stringify(generateCloudApiPayload(selectedReminder), null, 2)}
              </pre>
            </div>
          </div>

          {/* Setup Checklist */}
          <div className="p-4 rounded-3xl bg-slate-900/60 border border-white/[0.08] space-y-2">
            <h4 className="font-bold text-slate-200 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-purple-400" />
              Meta Cloud API Production Integration Steps
            </h4>
            <ol className="text-slate-400 space-y-1.5 list-decimal pl-4 leading-relaxed text-[11px]">
              <li>
                <strong className="text-slate-200">Register Meta App:</strong> Create a Business App on developers.facebook.com and configure the WhatsApp product.
              </li>
              <li>
                <strong className="text-slate-200">Add Sender Number:</strong> Register your official company phone number and complete business verification.
              </li>
              <li>
                <strong className="text-slate-200">Submit Template:</strong> Create the <code className="text-indigo-300 font-mono">yaadmate_reminder_alert</code> template for utility messages.
              </li>
              <li>
                <strong className="text-slate-200">Deploy Server Dispatcher:</strong> Run a Node.js backend cron job with your Permanent System User token to dispatch messages at exact timestamps.
              </li>
            </ol>
          </div>
        </div>
      )}
    </div>
  );
};
