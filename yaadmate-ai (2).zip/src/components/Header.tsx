import React from 'react';
import { Bell, Sparkles, Languages, CheckCircle2 } from 'lucide-react';
import { AppLanguage, UserPreferences } from '../types/reminder';
import { translations } from '../utils/translations';

interface HeaderProps {
  preferences: UserPreferences;
  onUpdatePreferences: (updated: Partial<UserPreferences>) => void;
  pendingCount: number;
  todayCount: number;
  notificationPermission: NotificationPermission | 'unsupported';
  onRequestNotificationPermission: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  preferences,
  onUpdatePreferences,
  pendingCount,
  todayCount,
  notificationPermission,
  onRequestNotificationPermission,
}) => {
  const t = translations[preferences.language];

  // Dynamic time-based greeting
  const hour = new Date().getHours();
  let greetingKey: keyof typeof t.greetings = 'morning';
  if (hour >= 12 && hour < 17) greetingKey = 'afternoon';
  else if (hour >= 17 && hour < 21) greetingKey = 'evening';
  else if (hour >= 21 || hour < 5) greetingKey = 'night';

  const greeting = t.greetings[greetingKey];

  // Formatted current date
  const now = new Date();
  const dateFormatted = now.toLocaleDateString(
    preferences.language === 'ur' ? 'ur-PK' : 'en-US',
    {
      weekday: 'long',
      month: 'short',
      day: 'numeric',
    }
  );

  const cycleLanguage = () => {
    const cycle: AppLanguage[] = ['en', 'ur-roman', 'ur'];
    const nextIdx = (cycle.indexOf(preferences.language) + 1) % cycle.length;
    onUpdatePreferences({ language: cycle[nextIdx] });
  };

  const getLangBadge = () => {
    if (preferences.language === 'en') return 'EN';
    if (preferences.language === 'ur-roman') return 'Roman';
    return 'اردو';
  };

  return (
    <header className="sticky top-0 z-30 bg-[#070b14]/90 backdrop-blur-xl border-b border-white/[0.08] px-4 pt-3 pb-3">
      {/* Top row: Brand & Status Controls */}
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2.5">
          <div className="relative flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 shadow-lg shadow-indigo-500/25">
            <Sparkles className="w-5 h-5 text-white" />
            <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-[#070b14]" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="font-bold text-lg text-white tracking-tight leading-none">
                {t.appName}
              </h1>
              <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                AI
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5 font-medium">
              {dateFormatted}
            </p>
          </div>
        </div>

        {/* Right Action Icons */}
        <div className="flex items-center gap-1.5">
          {/* Language Switcher */}
          <button
            onClick={cycleLanguage}
            title="Change language (English / Roman Urdu / Urdu)"
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 border border-white/10 text-xs font-medium text-slate-200 transition-all active:scale-95"
          >
            <Languages className="w-3.5 h-3.5 text-indigo-400" />
            <span>{getLangBadge()}</span>
          </button>

          {/* Notification Permission Bell */}
          <button
            onClick={onRequestNotificationPermission}
            title={
              notificationPermission === 'granted'
                ? 'Notifications Enabled'
                : 'Enable Notifications'
            }
            className={`relative p-2 rounded-xl border transition-all active:scale-95 ${
              notificationPermission === 'granted'
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                : 'bg-slate-800/80 hover:bg-slate-700/80 border-white/10 text-slate-300'
            }`}
          >
            <Bell className="w-4 h-4" />
            {notificationPermission === 'granted' ? (
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-emerald-400 ring-2 ring-[#070b14]" />
            ) : (
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-amber-400 animate-pulse ring-2 ring-[#070b14]" />
            )}
          </button>
        </div>
      </div>

      {/* Greeting and Quick Snapshot Bar */}
      <div className="flex items-center justify-between text-xs bg-gradient-to-r from-indigo-950/40 via-purple-950/20 to-transparent p-2.5 rounded-xl border border-indigo-500/15">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-indigo-400 animate-ping" />
          <span className="text-slate-200 font-medium">
            {greeting}, <span className="text-indigo-300 font-semibold">{preferences.userName || 'Friend'}</span>
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 font-semibold text-[11px]">
            {todayCount} {t.stats.today}
          </span>
          {pendingCount > todayCount && (
            <span className="text-slate-400 text-[11px]">
              ({pendingCount} {t.stats.total})
            </span>
          )}
        </div>
      </div>
    </header>
  );
};
