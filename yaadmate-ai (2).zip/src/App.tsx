/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Reminder,
  TabType,
  UserPreferences,
  AppLanguage,
} from './types/reminder';
import {
  loadReminders,
  saveReminders,
  loadPreferences,
  savePreferences,
  getInitialReminders,
} from './utils/storage';
import {
  getNextOccurrenceDate,
  getLocalTodayString,
  autoAdvanceRecurringReminders,
} from './utils/dateUtils';
import { playNotificationChime, triggerHaptic } from './utils/sound';
import {
  scheduleNativeReminderAlarm,
  cancelNativeReminderAlarm,
  cancelAllNativeReminders,
  initNativeScheduler,
  registerNativeActionListeners,
  requestNativeAndroidPermissions,
  requestExactAlarmPermission,
  triggerNativeAlarmHaptic,
  checkNotificationPermissionStatus,
  rescheduleAllActiveReminders,
  ScheduleResult,
} from './utils/nativeScheduler';
import { CheckCircle2, AlertTriangle, Info, X } from 'lucide-react';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { DashboardView } from './components/DashboardView';
import { AIAssistantTab } from './components/AIAssistantTab';
import { HistoryTab } from './components/HistoryTab';
import { WhatsAppTab } from './components/WhatsAppTab';
import { SettingsTab } from './components/SettingsTab';
import { ReminderModal } from './components/ReminderModal';
import { PostponeModal } from './components/PostponeModal';
import { NotificationBanner } from './components/NotificationBanner';
import { OnboardingModal } from './components/OnboardingModal';

export default function App() {
  // Global State
  const [reminders, setReminders] = useState<Reminder[]>(() => loadReminders());
  const [preferences, setPreferences] = useState<UserPreferences>(() => loadPreferences());
  const [currentTab, setCurrentTab] = useState<TabType>('home');

  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState<boolean>(
    () => !loadPreferences().hasSeenOnboarding
  );
  const [editingReminder, setEditingReminder] = useState<Reminder | null>(null);
  const [postponeTarget, setPostponeTarget] = useState<Reminder | null>(null);

  // Live due reminder alert
  const [activeDueReminder, setActiveDueReminder] = useState<Reminder | null>(null);

  // Scheduling toast feedback state
  interface ScheduleToast {
    id: string;
    type: 'success' | 'warning' | 'error' | 'info';
    message: string;
    actionLabel?: string;
    onAction?: () => void;
  }
  const [scheduleToast, setScheduleToast] = useState<ScheduleToast | null>(null);

  const showScheduleFeedback = (toast: Omit<ScheduleToast, 'id'>) => {
    const id = `toast-${Date.now()}`;
    setScheduleToast({ ...toast, id });
    setTimeout(() => {
      setScheduleToast((curr) => (curr?.id === id ? null : curr));
    }, 5500);
  };

  const handleScheduleResultFeedback = (res: ScheduleResult, reminder: Reminder) => {
    if (res.success && res.mechanism === 'native_exact_alarm') {
      showScheduleFeedback({
        type: 'success',
        message: `🔔 Alarm set for ${reminder.time} (${reminder.date}) with sound & vibration.`,
      });
    } else if (res.reason === 'exact_alarm_permission_required') {
      showScheduleFeedback({
        type: 'warning',
        message: 'Exact alarm permission required in Android settings for reliable alerts.',
        actionLabel: 'Settings',
        onAction: () => requestExactAlarmPermission(),
      });
    } else if (res.mechanism === 'web_in_app_only') {
      showScheduleFeedback({
        type: 'info',
        message: `Reminder saved for ${reminder.time}. (Active in-tab notification alert ready).`,
      });
    } else if (res.reason === 'past_time') {
      showScheduleFeedback({
        type: 'warning',
        message: 'Selected date and time is in the past. Reminder saved without future alarm.',
      });
    } else if (!res.success) {
      showScheduleFeedback({
        type: 'error',
        message: res.reason || 'Could not schedule native alarm.',
      });
    } else {
      showScheduleFeedback({
        type: 'success',
        message: `Reminder scheduled for ${reminder.time} (${reminder.date}).`,
      });
    }
  };

  // Notification API state
  const [notificationPermission, setNotificationPermission] = useState<
    NotificationPermission | 'unsupported'
  >(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission;
    }
    return 'unsupported';
  });

  // Keep track of reminders in ref for interval check
  const remindersRef = useRef(reminders);
  remindersRef.current = reminders;
  const preferencesRef = useRef(preferences);
  preferencesRef.current = preferences;

  // Persist reminders whenever updated
  useEffect(() => {
    saveReminders(reminders);
  }, [reminders]);

  // Persist preferences whenever updated
  const handleUpdatePreferences = (updates: Partial<UserPreferences>) => {
    setPreferences((prev) => {
      const next = { ...prev, ...updates };
      savePreferences(next);
      return next;
    });
  };

  // Sync RTL / LTR document direction when language changes
  useEffect(() => {
    if (preferences.language === 'ur') {
      document.documentElement.setAttribute('dir', 'rtl');
    } else {
      document.documentElement.setAttribute('dir', 'ltr');
    }
  }, [preferences.language]);

  // Initialize native Android notification channels, sync recurring reminders, and register listeners
  useEffect(() => {
    initNativeScheduler().then(async () => {
      // Auto-advance any recurring reminders whose scheduled time arrived
      const { updatedReminders, newScheduledInstances } = autoAdvanceRecurringReminders(
        remindersRef.current
      );
      if (newScheduledInstances.length > 0) {
        setReminders(updatedReminders);
      }
      await rescheduleAllActiveReminders(updatedReminders);
    });

    checkNotificationPermissionStatus().then((status) => {
      setNotificationPermission(status === 'prompt' ? 'default' : status);
    });

    const cleanup = registerNativeActionListeners(
      (id) => {
        handleToggleComplete(id);
      },
      (id, minutes) => {
        handleQuickSnooze(id, minutes);
      }
    );

    // Reschedule and advance recurring reminders on app resume
    const handleSyncOnResume = () => {
      if (document.visibilityState === 'visible') {
        const { updatedReminders, newScheduledInstances } = autoAdvanceRecurringReminders(
          remindersRef.current
        );
        if (newScheduledInstances.length > 0) {
          setReminders(updatedReminders);
          newScheduledInstances.forEach((inst) => {
            scheduleNativeReminderAlarm(inst);
          });
        }
        rescheduleAllActiveReminders(updatedReminders);
      }
    };

    document.addEventListener('visibilitychange', handleSyncOnResume);
    window.addEventListener('focus', handleSyncOnResume);

    return () => {
      cleanup();
      document.removeEventListener('visibilitychange', handleSyncOnResume);
      window.removeEventListener('focus', handleSyncOnResume);
    };
  }, []);

  // Request native Android or browser notification permission with safe fallback
  const handleRequestNotificationPermission = async () => {
    try {
      const permission = await requestNativeAndroidPermissions();
      setNotificationPermission(permission === 'prompt' ? 'default' : permission);

      if (permission === 'granted') {
        playNotificationChime();
        triggerNativeAlarmHaptic();
        try {
          if (
            typeof window !== 'undefined' &&
            'Notification' in window &&
            Notification.permission === 'granted'
          ) {
            new Notification('YaadMate AI', {
              body: 'Notifications enabled! You will receive timely alerts for your reminders.',
            });
          }
        } catch (e) {
          console.warn('System notification blocked in iframe, in-app alerts active:', e);
        }
      }
    } catch (err) {
      console.warn('Notification permission request error:', err);
    }
  };

  // Trigger browser or in-app notification for a reminder
  const fireNotification = useCallback((reminder: Reminder) => {
    if (preferencesRef.current.soundEnabled) {
      playNotificationChime();
    }
    if (preferencesRef.current.vibrateEnabled) {
      triggerHaptic([100, 50, 100, 50, 200]);
      triggerNativeAlarmHaptic();
    }

    // Always show the premium in-app due reminder dialog
    setActiveDueReminder(reminder);

    // If browser notifications are granted, attempt system notification
    if (
      typeof window !== 'undefined' &&
      'Notification' in window &&
      Notification.permission === 'granted'
    ) {
      try {
        new Notification(`🔔 ${reminder.title}`, {
          body: reminder.description || `Due at ${reminder.time} (${reminder.category})`,
          tag: reminder.id,
        });
      } catch (err) {
        // Silently catch iframe notification restrictions
      }
    }
  }, []);

  // Active Reminder Timer: Checks every 8 seconds with leadTime support and local date accuracy
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const leadMs = (preferencesRef.current.leadTimeMinutes || 0) * 60 * 1000;

      // 1. Check if any recurring reminder passed its time and needs next occurrence scheduled automatically
      const { updatedReminders, newScheduledInstances } = autoAdvanceRecurringReminders(
        remindersRef.current
      );
      if (newScheduledInstances.length > 0) {
        setReminders(updatedReminders);
        newScheduledInstances.forEach((inst) => {
          scheduleNativeReminderAlarm(inst);
        });
      }

      // 2. Check for due reminders
      remindersRef.current.forEach((r) => {
        // Skip completed or already notified
        if (r.completed || r.notified) return;

        // Compare timestamps accurately
        const reminderTime = new Date(`${r.date}T${r.time}:00`).getTime();
        const alertTriggerTime = reminderTime - leadMs;

        // If current time has reached or passed trigger time
        if (now.getTime() >= alertTriggerTime) {
          // Mark notified so we don't alert repeatedly
          setReminders((prev) =>
            prev.map((item) => (item.id === r.id ? { ...item, notified: true } : item))
          );
          fireNotification(r);
        }
      });
    }, 8000);

    return () => clearInterval(interval);
  }, [fireNotification]);

  // CRUD Actions
  const handleSaveReminder = async (
    reminderData: Omit<Reminder, 'id' | 'createdAt' | 'completed' | 'postponeCount'>
  ) => {
    if (editingReminder) {
      // Update existing
      const updatedReminder: Reminder = {
        ...editingReminder,
        ...reminderData,
        notified: false, // Reset notified if time/date was changed
      };
      setReminders((prev) =>
        prev.map((r) => (r.id === editingReminder.id ? updatedReminder : r))
      );
      setEditingReminder(null);
      const res = await scheduleNativeReminderAlarm(updatedReminder);
      handleScheduleResultFeedback(res, updatedReminder);
    } else {
      // Add new
      const newReminder: Reminder = {
        ...reminderData,
        id: `rem-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        completed: false,
        createdAt: new Date().toISOString(),
        notified: false,
        postponeCount: 0,
      };
      setReminders((prev) => [newReminder, ...prev]);
      const res = await scheduleNativeReminderAlarm(newReminder);
      handleScheduleResultFeedback(res, newReminder);
    }
  };

  // Toggle complete with automatic recurring reminder progression
  const handleToggleComplete = (id: string) => {
    let nextRecurringReminder: Reminder | null = null;

    setReminders((prev) => {
      const updated = prev.map((r) => {
        if (r.id === id) {
          const willBeCompleted = !r.completed;

          // If completing a recurring reminder, calculate the next instance
          if (willBeCompleted && r.recurrence !== 'none') {
            const nextDate = getNextOccurrenceDate(r.date, r.recurrence);
            nextRecurringReminder = {
              ...r,
              id: `rem-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
              date: nextDate,
              completed: false,
              completedAt: undefined,
              createdAt: new Date().toISOString(),
              notified: false,
              postponeCount: 0,
            };
          }

          return {
            ...r,
            completed: willBeCompleted,
            completedAt: willBeCompleted ? new Date().toISOString() : undefined,
          };
        }
        return r;
      });

      // If a new recurring instance was scheduled, insert it into the active list
      if (nextRecurringReminder) {
        scheduleNativeReminderAlarm(nextRecurringReminder);
        return [nextRecurringReminder, ...updated];
      }

      return updated;
    });

    cancelNativeReminderAlarm(id);

    // If active due alert is open for this reminder, close it
    if (activeDueReminder && activeDueReminder.id === id) {
      setActiveDueReminder(null);
    }
  };

  const handleDeleteReminder = (id: string) => {
    cancelNativeReminderAlarm(id);
    setReminders((prev) => prev.filter((r) => r.id !== id));
    if (activeDueReminder && activeDueReminder.id === id) {
      setActiveDueReminder(null);
    }
    showScheduleFeedback({
      type: 'info',
      message: 'Reminder deleted and alarm cancelled.',
    });
  };

  const handlePostponeReminder = async (reminderId: string, newDate: string, newTime: string) => {
    let targetPostponed: Reminder | null = null;

    setReminders((prev) =>
      prev.map((r) => {
        if (r.id === reminderId) {
          const postponed = {
            ...r,
            date: newDate,
            time: newTime,
            notified: false, // Reset so it can alert again at the postponed time
            postponeCount: (r.postponeCount || 0) + 1,
          };
          targetPostponed = postponed;
          return postponed;
        }
        return r;
      })
    );

    if (activeDueReminder && activeDueReminder.id === reminderId) {
      setActiveDueReminder(null);
    }

    if (targetPostponed) {
      const res = await scheduleNativeReminderAlarm(targetPostponed);
      handleScheduleResultFeedback(res, targetPostponed);
    }
  };

  // Quick Snooze helper (+5m, +10m, +15m, +1h)
  const handleQuickSnooze = (reminderId: string, minutes: number) => {
    const snoozeTime = new Date(Date.now() + minutes * 60 * 1000);
    const newDate = getLocalTodayString(snoozeTime);
    const hours = String(snoozeTime.getHours()).padStart(2, '0');
    const mins = String(snoozeTime.getMinutes()).padStart(2, '0');
    const newTime = `${hours}:${mins}`;

    handlePostponeReminder(reminderId, newDate, newTime);
  };

  const handleClearCompleted = () => {
    setReminders((prev) => prev.filter((r) => !r.completed));
  };

  const handleImportReminders = (imported: Reminder[]) => {
    setReminders(imported);
    // Schedule all uncompleted upcoming reminders
    imported.forEach((r) => {
      if (!r.completed) {
        scheduleNativeReminderAlarm(r);
      }
    });
  };

  const handleResetReminders = () => {
    cancelAllNativeReminders();
    const initial = getInitialReminders();
    setReminders(initial);
    initial.forEach((r) => {
      if (!r.completed) {
        scheduleNativeReminderAlarm(r);
      }
    });
  };

  // Safe WhatsApp sharing helper with clipboard fallback
  const handleShareToWhatsApp = (reminder: Reminder) => {
    const text = `*🔔 YaadMate AI Reminder*\n\n📌 *Task:* ${reminder.title}\n📅 *Date:* ${reminder.date}\n⏰ *Time:* ${reminder.time}\n🏷️ *Category:* ${reminder.category}\n⚡ *Priority:* ${reminder.priority.toUpperCase()}${
      reminder.description ? `\n📝 *Notes:* ${reminder.description}` : ''
    }\n\n_Sent via YaadMate AI_`;
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;

    try {
      const link = document.createElement('a');
      link.href = url;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch {
      navigator.clipboard.writeText(text);
    }
  };

  // Test Notification Trigger from Settings
  const handleTriggerTestNotification = () => {
    const testReminder: Reminder = {
      id: 'test-reminder',
      title: 'Water & Posture Break (Test Alert)',
      description: 'This is a test notification from YaadMate AI to verify audio and alert popups.',
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }),
      category: 'Health',
      priority: 'high',
      recurrence: 'none',
      completed: false,
      createdAt: new Date().toISOString(),
    };
    fireNotification(testReminder);
  };

  const pendingCount = reminders.filter((r) => !r.completed).length;
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  const todayCount = reminders.filter((r) => !r.completed && r.date === todayStr).length;

  return (
    <div
      className={`min-h-screen bg-[#070b14] text-slate-100 flex flex-col font-sans transition-colors duration-300 ${
        preferences.theme === 'midnight'
          ? 'bg-black'
          : preferences.theme === 'cyber'
          ? 'bg-[#0b081d]'
          : preferences.theme === 'emerald'
          ? 'bg-[#05140f]'
          : 'bg-[#070b14]'
      }`}
    >
      {/* Top Header */}
      <Header
        preferences={preferences}
        onUpdatePreferences={handleUpdatePreferences}
        pendingCount={pendingCount}
        todayCount={todayCount}
        notificationPermission={notificationPermission}
        onRequestNotificationPermission={handleRequestNotificationPermission}
      />

      {/* Notification Banner & Live Due Reminder Alert Popup */}
      <NotificationBanner
        permission={notificationPermission}
        onRequestPermission={handleRequestNotificationPermission}
        language={preferences.language}
        activeDueReminder={activeDueReminder}
        soundEnabled={preferences.soundEnabled}
        vibrateEnabled={preferences.vibrateEnabled}
        speechAnnouncementsEnabled={preferences.speechAnnouncementsEnabled}
        alarmSound={preferences.alarmSound}
        onDismissDueAlert={() => setActiveDueReminder(null)}
        onCompleteDueReminder={handleToggleComplete}
        onQuickSnooze={handleQuickSnooze}
        onOpenCustomPostpone={(rem) => {
          setActiveDueReminder(null);
          setPostponeTarget(rem);
        }}
      />

      {/* Main Tab Content */}
      <main className="flex-1 overflow-x-hidden">
        {currentTab === 'home' && (
          <DashboardView
            reminders={reminders}
            language={preferences.language}
            soundEnabled={preferences.soundEnabled}
            vibrateEnabled={preferences.vibrateEnabled}
            onToggleComplete={handleToggleComplete}
            onOpenEdit={(r) => {
              setEditingReminder(r);
              setIsModalOpen(true);
            }}
            onOpenPostpone={(r) => setPostponeTarget(r)}
            onDelete={handleDeleteReminder}
            onOpenAddModal={() => {
              setEditingReminder(null);
              setIsModalOpen(true);
            }}
            onNavigateToChat={() => setCurrentTab('chat')}
            onShareToWhatsApp={handleShareToWhatsApp}
          />
        )}

        {currentTab === 'chat' && (
          <AIAssistantTab
            reminders={reminders}
            onAddReminder={handleSaveReminder}
            language={preferences.language}
            onNavigateTab={(tab) => setCurrentTab(tab as TabType)}
          />
        )}

        {currentTab === 'history' && (
          <HistoryTab
            reminders={reminders}
            onToggleComplete={handleToggleComplete}
            onDelete={handleDeleteReminder}
            onClearCompleted={handleClearCompleted}
            language={preferences.language}
          />
        )}

        {currentTab === 'whatsapp' && (
          <WhatsAppTab reminders={reminders} language={preferences.language} />
        )}

        {currentTab === 'settings' && (
          <SettingsTab
            preferences={preferences}
            onUpdatePreferences={handleUpdatePreferences}
            reminders={reminders}
            onImportReminders={handleImportReminders}
            onResetReminders={handleResetReminders}
            onTriggerTestNotification={handleTriggerTestNotification}
            onOpenOnboarding={() => setIsOnboardingOpen(true)}
          />
        )}
      </main>

      {/* Bottom Navigation Dock */}
      <BottomNav
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        onOpenAddModal={() => {
          setEditingReminder(null);
          setIsModalOpen(true);
        }}
        language={preferences.language}
        pendingCount={pendingCount}
      />

      {/* Reminder Add/Edit Modal */}
      <ReminderModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingReminder(null);
        }}
        onSave={handleSaveReminder}
        initialReminder={editingReminder}
        language={preferences.language}
      />

      {/* Postpone / Snooze Modal */}
      <PostponeModal
        isOpen={Boolean(postponeTarget)}
        onClose={() => setPostponeTarget(null)}
        reminder={postponeTarget}
        language={preferences.language}
        onPostpone={handlePostponeReminder}
      />

      {/* Onboarding & Permissions Tour Modal */}
      <OnboardingModal
        isOpen={isOnboardingOpen}
        onClose={() => {
          setIsOnboardingOpen(false);
          handleUpdatePreferences({ hasSeenOnboarding: true });
        }}
        language={preferences.language}
        notificationPermission={notificationPermission}
        onRequestNotificationPermission={handleRequestNotificationPermission}
      />

      {/* Real-time Schedule & Alarm Feedback Toast */}
      {scheduleToast && (
        <div className="fixed bottom-20 left-4 right-4 z-40 max-w-sm mx-auto animate-in slide-in-from-bottom-5 fade-in duration-200 pointer-events-auto">
          <div
            className={`p-3.5 rounded-2xl border shadow-xl flex items-center justify-between gap-2.5 backdrop-blur-lg ${
              scheduleToast.type === 'success'
                ? 'bg-emerald-950/90 border-emerald-500/40 text-emerald-200'
                : scheduleToast.type === 'warning'
                ? 'bg-amber-950/90 border-amber-500/40 text-amber-200'
                : scheduleToast.type === 'error'
                ? 'bg-rose-950/90 border-rose-500/40 text-rose-200'
                : 'bg-slate-900/90 border-indigo-500/40 text-indigo-200'
            }`}
          >
            <div className="flex items-center gap-2 flex-1 text-xs font-medium">
              {scheduleToast.type === 'success' && (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              )}
              {scheduleToast.type === 'warning' && (
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              )}
              {scheduleToast.type === 'error' && (
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              )}
              {scheduleToast.type === 'info' && (
                <Info className="w-4 h-4 text-indigo-400 shrink-0" />
              )}
              <span className="leading-snug">{scheduleToast.message}</span>
            </div>

            {scheduleToast.actionLabel && scheduleToast.onAction && (
              <button
                onClick={() => {
                  scheduleToast.onAction?.();
                  setScheduleToast(null);
                }}
                className="px-2.5 py-1 rounded-xl bg-white/20 hover:bg-white/30 text-white font-bold text-[11px] shrink-0 transition-colors"
              >
                {scheduleToast.actionLabel}
              </button>
            )}

            <button
              onClick={() => setScheduleToast(null)}
              className="p-1 rounded-full text-slate-400 hover:text-white transition-colors shrink-0"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
