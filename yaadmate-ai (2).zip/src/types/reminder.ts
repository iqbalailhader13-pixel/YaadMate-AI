export type ReminderCategory =
  | 'Work'
  | 'Personal'
  | 'Health'
  | 'Shopping'
  | 'Meeting'
  | 'Important'
  | 'Finance';

export type ReminderPriority = 'low' | 'medium' | 'high' | 'urgent';

export type ReminderRecurrence = 'none' | 'daily' | 'weekly' | 'weekdays' | 'monthly';

export interface Reminder {
  id: string;
  title: string;
  description: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM (24h)
  category: ReminderCategory;
  priority: ReminderPriority;
  recurrence: ReminderRecurrence;
  completed: boolean;
  completedAt?: string;
  createdAt: string;
  notified?: boolean;
  postponeCount?: number;
}

export type TabType = 'home' | 'chat' | 'history' | 'settings' | 'whatsapp';

export type AppLanguage = 'en' | 'ur' | 'ur-roman';

export type AppTheme = 'navy' | 'midnight' | 'cyber' | 'emerald';

export type AlarmSoundType = 'melodic' | 'digital' | 'radar';

export interface UserPreferences {
  language: AppLanguage;
  theme: AppTheme;
  soundEnabled: boolean;
  vibrateEnabled: boolean;
  speechAnnouncementsEnabled: boolean;
  alarmSound: AlarmSoundType;
  leadTimeMinutes: number; // 0 (on time), 5, 10, 15
  userName: string;
  hasSeenOnboarding?: boolean;
}
