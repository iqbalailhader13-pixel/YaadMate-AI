import { ReminderRecurrence, AppLanguage, Reminder } from '../types/reminder';

/**
 * Returns YYYY-MM-DD in the user's LOCAL timezone (not UTC).
 */
export function getLocalTodayString(refDate: Date = new Date()): string {
  const y = refDate.getFullYear();
  const m = String(refDate.getMonth() + 1).padStart(2, '0');
  const d = String(refDate.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/**
 * Returns HH:MM in 24h format in the user's LOCAL timezone.
 */
export function getLocalTimeString(refDate: Date = new Date()): string {
  const h = String(refDate.getHours()).padStart(2, '0');
  const m = String(refDate.getMinutes()).padStart(2, '0');
  return `${h}:${m}`;
}

/**
 * Check if a reminder is overdue relative to local time
 */
export function isOverdue(dateStr: string, timeStr: string, now: Date = new Date()): boolean {
  const dt = new Date(`${dateStr}T${timeStr}:00`);
  return dt.getTime() < now.getTime();
}

/**
 * Calculate the next scheduled date for a recurring reminder
 */
export function getNextOccurrenceDate(
  currentDateStr: string,
  recurrence: ReminderRecurrence
): string {
  if (recurrence === 'none') return currentDateStr;

  // Parse YYYY-MM-DD into a local Date
  const [y, m, d] = currentDateStr.split('-').map((v) => parseInt(v, 10));
  const date = new Date(y, m - 1, d);

  if (recurrence === 'daily') {
    date.setDate(date.getDate() + 1);
  } else if (recurrence === 'weekly') {
    date.setDate(date.getDate() + 7);
  } else if (recurrence === 'weekdays') {
    const dayOfWeek = date.getDay(); // 0 is Sunday, 5 is Friday, 6 is Saturday
    if (dayOfWeek === 5) {
      date.setDate(date.getDate() + 3); // Friday -> Monday
    } else if (dayOfWeek === 6) {
      date.setDate(date.getDate() + 2); // Saturday -> Monday
    } else {
      date.setDate(date.getDate() + 1); // Monday-Thursday -> next day
    }
  } else if (recurrence === 'monthly') {
    date.setMonth(date.getMonth() + 1);
  }

  return getLocalTodayString(date);
}

/**
 * Format date for friendly localized display
 */
export function formatFriendlyDate(dateStr: string, language: AppLanguage): string {
  const todayStr = getLocalTodayString();
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = getLocalTodayString(tomorrow);

  if (dateStr === todayStr) {
    if (language === 'ur') return 'آج';
    if (language === 'ur-roman') return 'Aaj';
    return 'Today';
  }

  if (dateStr === tomorrowStr) {
    if (language === 'ur') return 'کل';
    if (language === 'ur-roman') return 'Kal';
    return 'Tomorrow';
  }

  try {
    const [y, m, d] = dateStr.split('-').map((v) => parseInt(v, 10));
    const dt = new Date(y, m - 1, d);
    return dt.toLocaleDateString(language === 'ur' ? 'ur-PK' : 'en-US', {
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return dateStr;
  }
}

/**
 * Automatically advances recurring reminders whose scheduled time has arrived or passed.
 * Generates the next upcoming instance and registers its native Android alarm
 * even if the user never manually completed the previous reminder.
 */
export function autoAdvanceRecurringReminders(reminders: Reminder[]): {
  updatedReminders: Reminder[];
  newScheduledInstances: Reminder[];
} {
  const now = new Date();
  const newInstances: Reminder[] = [];
  let hasChanges = false;

  const updated = reminders.map((r) => {
    // Only process recurring reminders
    if (!r.recurrence || r.recurrence === 'none') return r;

    const timeFormatted = r.time.length === 5 ? `${r.time}:00` : r.time;
    const scheduledTime = new Date(`${r.date}T${timeFormatted}`);

    // If this reminder is due or in the past
    if (now.getTime() >= scheduledTime.getTime()) {
      let nextDate = getNextOccurrenceDate(r.date, r.recurrence);
      const todayStr = getLocalTodayString(now);

      // Keep advancing until nextDate is upcoming in local time
      while (
        nextDate < todayStr ||
        (nextDate === todayStr &&
          now.getTime() >= new Date(`${nextDate}T${timeFormatted}`).getTime())
      ) {
        nextDate = getNextOccurrenceDate(nextDate, r.recurrence);
      }

      // Check if an uncompleted future instance already exists with the same title, time, and recurrence
      const alreadyScheduled =
        reminders.some(
          (other) =>
            other.title === r.title &&
            other.time === r.time &&
            other.date === nextDate &&
            !other.completed
        ) ||
        newInstances.some(
          (other) =>
            other.title === r.title &&
            other.time === r.time &&
            other.date === nextDate
        );

      if (!alreadyScheduled) {
        const nextReminder: Reminder = {
          ...r,
          id: `rem-rec-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
          date: nextDate,
          completed: false,
          completedAt: undefined,
          createdAt: new Date().toISOString(),
          notified: false,
          postponeCount: 0,
        };
        newInstances.push(nextReminder);
        hasChanges = true;
      }
    }
    return r;
  });

  return {
    updatedReminders: hasChanges ? [...newInstances, ...updated] : updated,
    newScheduledInstances: newInstances,
  };
}
