import {
  LocalNotifications,
  Channel,
  ScheduleOptions,
  PermissionStatus as LocalNotificationPermissionStatus,
  SettingsPermissionStatus,
} from '@capacitor/local-notifications';
import { Capacitor } from '@capacitor/core';
import { Haptics, NotificationType } from '@capacitor/haptics';
import { Reminder } from '../types/reminder';

/**
 * Android Notification Channel for YaadMate Alarms & Exact Reminders
 */
export const YAADMATE_ALARM_CHANNEL_ID = 'yaadmate_alarm_channel';

// State flag to avoid registering channels multiple times
let isInitialized = false;

/**
 * Result returned when scheduling a reminder alarm
 */
export interface ScheduleResult {
  success: boolean;
  mechanism: 'native_exact_alarm' | 'web_in_app_only' | 'error';
  reason?: string;
  scheduledTime?: string;
}

/**
 * Returns true if running inside a native Android or iOS Capacitor container.
 */
export function isNativePlatform(): boolean {
  return typeof window !== 'undefined' && Capacitor.isNativePlatform();
}

/**
 * Generates a stable positive 32-bit integer ID from a reminder string ID
 * required by Android AlarmManager / NotificationManager.
 */
export function getNumericNotificationId(id: string): number {
  let hash = 0;
  for (let i = 0; i < id.length; i++) {
    const char = id.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0; // Convert to 32bit integer
  }
  return Math.abs(hash) % 2147483647;
}

/**
 * Initializes Android notification channels and interactive action buttons.
 * Must be called early in the application lifecycle.
 */
export async function initNativeScheduler(): Promise<void> {
  if (isInitialized) return;

  if (isNativePlatform()) {
    try {
      // 1. Create High-Priority Notification Channel for Alarms
      const channel: Channel = {
        id: YAADMATE_ALARM_CHANNEL_ID,
        name: 'YaadMate Alarms & Urgent Reminders',
        description: 'Plays loud alarm ringtones and high-priority vibrations for due reminders',
        importance: 5, // NotificationManager.IMPORTANCE_HIGH (heads-up banner with sound & vibration)
        visibility: 1, // VISIBILITY_PUBLIC (shows on lock screen)
        sound: 'alarm.wav',
        vibration: true,
        lights: true,
        lightColor: '#6366F1',
      };
      await LocalNotifications.createChannel(channel);

      // 2. Register Interactive Action Buttons
      await LocalNotifications.registerActionTypes({
        types: [
          {
            id: 'REMINDER_ACTIONS',
            actions: [
              {
                id: 'DONE',
                title: '✅ Mark Complete',
              },
              {
                id: 'SNOOZE_10',
                title: '⏰ Snooze 10m',
              },
              {
                id: 'SNOOZE_60',
                title: '⏳ Snooze 1h',
              },
            ],
          },
        ],
      });

      isInitialized = true;
    } catch (err) {
      console.warn('[YaadMate] Error initializing native notification channels:', err);
    }
  }
}

/**
 * Request native Android notification permissions (POST_NOTIFICATIONS on Android 13+)
 */
export async function requestNativeAndroidPermissions(): Promise<'granted' | 'denied' | 'prompt'> {
  if (isNativePlatform()) {
    try {
      const res: LocalNotificationPermissionStatus = await LocalNotifications.requestPermissions();
      return res.display === 'granted' ? 'granted' : res.display === 'denied' ? 'denied' : 'prompt';
    } catch (err) {
      console.warn('[YaadMate] Native permission request error:', err);
    }
  }

  // Web API fallback
  if (typeof window !== 'undefined' && 'Notification' in window) {
    try {
      const perm = await Notification.requestPermission();
      return perm === 'granted' ? 'granted' : perm === 'denied' ? 'denied' : 'prompt';
    } catch {
      return 'denied';
    }
  }

  return 'denied';
}

/**
 * Checks current notification permission status.
 */
export async function checkNotificationPermissionStatus(): Promise<'granted' | 'denied' | 'prompt'> {
  if (isNativePlatform()) {
    try {
      const res = await LocalNotifications.checkPermissions();
      return res.display === 'granted' ? 'granted' : res.display === 'denied' ? 'denied' : 'prompt';
    } catch (err) {
      console.warn('[YaadMate] Error checking native permissions:', err);
    }
  }

  if (typeof window !== 'undefined' && 'Notification' in window) {
    const perm = Notification.permission;
    return perm === 'granted' ? 'granted' : perm === 'denied' ? 'denied' : 'prompt';
  }

  return 'prompt';
}

/**
 * Check Android 12+ Exact Alarm Permission (SCHEDULE_EXACT_ALARM / USE_EXACT_ALARM).
 */
export async function checkExactAlarmPermission(): Promise<'granted' | 'denied' | 'prompt'> {
  if (isNativePlatform()) {
    try {
      const res: SettingsPermissionStatus = await LocalNotifications.checkExactNotificationSetting();
      return res.exact_alarm === 'granted' ? 'granted' : 'prompt';
    } catch (err) {
      console.warn('[YaadMate] Exact alarm check error:', err);
    }
  }
  return 'granted';
}

/**
 * Opens the Android system settings screen to allow exact alarms.
 */
export async function requestExactAlarmPermission(): Promise<'granted' | 'denied' | 'prompt'> {
  if (isNativePlatform()) {
    try {
      const res = await LocalNotifications.changeExactNotificationSetting();
      return res.exact_alarm === 'granted' ? 'granted' : 'denied';
    } catch (err) {
      console.warn('[YaadMate] Error changing exact alarm setting:', err);
    }
  }
  return 'granted';
}

/**
 * Schedules a reminder alarm with exact timing, sound, vibration, and wake-from-doze support.
 * On Android, uses Capacitor LocalNotifications + AlarmManager.
 * On Web, accurately reports that background OS alarms require native Android, while keeping
 * the in-tab high-precision interval active.
 */
export async function scheduleNativeReminderAlarm(reminder: Reminder): Promise<ScheduleResult> {
  const timeFormatted = reminder.time.length === 5 ? `${reminder.time}:00` : reminder.time;
  const scheduledTime = new Date(`${reminder.date}T${timeFormatted}`);

  if (isNaN(scheduledTime.getTime())) {
    return {
      success: false,
      mechanism: 'error',
      reason: 'Invalid reminder date or time format.',
    };
  }

  // Don't schedule if already in past
  if (scheduledTime.getTime() <= Date.now()) {
    return {
      success: false,
      mechanism: 'error',
      reason: 'Reminder date and time is in the past.',
    };
  }

  const numericId = getNumericNotificationId(reminder.id);

  if (isNativePlatform()) {
    try {
      await initNativeScheduler();

      // Check exact alarm permission on Android 12+ (SCHEDULE_EXACT_ALARM)
      const exactStatus = await checkExactAlarmPermission();
      if (exactStatus !== 'granted') {
        return {
          success: false,
          mechanism: 'error',
          reason: 'exact_alarm_permission_required',
        };
      }

      const options: ScheduleOptions = {
        notifications: [
          {
            id: numericId,
            title: `🔔 ${reminder.title}`,
            body: reminder.description || `Due at ${reminder.time} (${reminder.category})`,
            schedule: {
              at: scheduledTime,
              allowWhileIdle: true, // Wakes Android device from Doze mode (Exact AlarmManager)
            },
            channelId: YAADMATE_ALARM_CHANNEL_ID,
            smallIcon: 'ic_stat_alarm',
            iconColor: '#6366F1',
            sound: 'alarm.wav',
            actionTypeId: 'REMINDER_ACTIONS',
            extra: {
              reminderId: reminder.id,
              title: reminder.title,
              category: reminder.category,
              priority: reminder.priority,
            },
          },
        ],
      };

      await LocalNotifications.schedule(options);
      return {
        success: true,
        mechanism: 'native_exact_alarm',
        scheduledTime: scheduledTime.toISOString(),
      };
    } catch (err: any) {
      console.warn('[YaadMate] Native local notification schedule error:', err);
      return {
        success: false,
        mechanism: 'error',
        reason: err?.message || 'Failed to schedule native alarm.',
      };
    }
  }

  // Web Browser mode: Accurately report that background OS alarms are native-only.
  // The app will continue monitoring this reminder via its in-tab precision timer.
  return {
    success: false,
    mechanism: 'web_in_app_only',
    reason:
      'Web browsers cannot register background OS alarms when closed. Active in-tab alerts remain active.',
  };
}

/**
 * Reschedules all active uncompleted reminders in the future.
 * Ensures reminders survive device restart and app closure.
 */
export async function rescheduleAllActiveReminders(reminders: Reminder[]): Promise<number> {
  if (!isNativePlatform()) return 0;

  try {
    await initNativeScheduler();
    const now = Date.now();
    let scheduledCount = 0;

    for (const r of reminders) {
      if (r.completed) continue;

      const timeFormatted = r.time.length === 5 ? `${r.time}:00` : r.time;
      const targetTime = new Date(`${r.date}T${timeFormatted}`).getTime();

      if (targetTime > now) {
        const res = await scheduleNativeReminderAlarm(r);
        if (res.success) scheduledCount++;
      }
    }

    return scheduledCount;
  } catch (err) {
    console.warn('[YaadMate] Error rescheduling active reminders:', err);
    return 0;
  }
}

/**
 * Cancels a scheduled native Android notification or alarm.
 */
export async function cancelNativeReminderAlarm(reminderId: string): Promise<void> {
  if (isNativePlatform()) {
    try {
      const numericId = getNumericNotificationId(reminderId);
      await LocalNotifications.cancel({ notifications: [{ id: numericId }] });
    } catch (err) {
      console.warn('[YaadMate] Error canceling native notification:', err);
    }
  }
}

/**
 * Cancels all scheduled native notifications.
 */
export async function cancelAllNativeReminders(): Promise<void> {
  if (isNativePlatform()) {
    try {
      await LocalNotifications.cancelAll();
    } catch (err) {
      console.warn('[YaadMate] Error canceling all native notifications:', err);
    }
  }
}

/**
 * Triggers native haptic feedback vibration using Capacitor Haptics.
 */
export async function triggerNativeAlarmHaptic(): Promise<void> {
  if (isNativePlatform()) {
    try {
      await Haptics.notification({ type: NotificationType.Warning });
      await Haptics.vibrate({ duration: 800 });
      return;
    } catch (err) {
      console.warn('[YaadMate] Haptics error:', err);
    }
  }

  // Fallback to Web Vibration API
  if (typeof window !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate([200, 100, 300, 100, 500]);
    } catch {
      // Ignore vibration error on unsupported platforms
    }
  }
}

/**
 * Registers native event listeners for when notifications are displayed or interacted with.
 */
export function registerNativeActionListeners(
  onComplete: (id: string) => void,
  onSnooze: (id: string, minutes: number) => void
): () => void {
  if (!isNativePlatform()) {
    return () => {};
  }

  let cleanupActionPerformed: (() => void) | null = null;
  let cleanupReceived: (() => void) | null = null;

  try {
    LocalNotifications.addListener('localNotificationReceived', () => {
      // Trigger haptic vibration when alarm arrives
      triggerNativeAlarmHaptic();
    }).then((handle) => {
      cleanupReceived = () => handle.remove();
    });

    LocalNotifications.addListener('localNotificationActionPerformed', (action) => {
      const reminderId = action.notification?.extra?.reminderId;
      if (!reminderId) return;

      if (action.actionId === 'DONE') {
        onComplete(reminderId);
      } else if (action.actionId === 'SNOOZE_10') {
        onSnooze(reminderId, 10);
      } else if (action.actionId === 'SNOOZE_60') {
        onSnooze(reminderId, 60);
      }
    }).then((handle) => {
      cleanupActionPerformed = () => handle.remove();
    });
  } catch (err) {
    console.warn('[YaadMate] Could not register native notification listeners:', err);
  }

  return () => {
    if (cleanupReceived) cleanupReceived();
    if (cleanupActionPerformed) cleanupActionPerformed();
  };
}
