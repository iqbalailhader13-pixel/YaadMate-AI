import { isNativePlatform } from './nativeScheduler';

// Default hosted Cloud Run backend for native APK builds
export const DEFAULT_HOSTED_BACKEND_URL =
  'https://ais-dev-q3dphbuxasxdaqtxxzwkvx-934523688755.asia-southeast1.run.app';

/**
 * Resolves the full URL for backend API endpoints.
 * - In web browser: uses relative path '/api/...'
 * - In native Android APK: routes to the hosted Cloud Run server to keep Gemini API keys secure
 *   on the server while allowing the APK to perform AI tasks.
 */
export function getApiUrl(endpointPath: string, customBaseUrl?: string): string {
  const cleanPath = endpointPath.startsWith('/') ? endpointPath : `/${endpointPath}`;

  // 1. If custom backend URL is configured in settings
  if (customBaseUrl && customBaseUrl.trim().length > 0) {
    return `${customBaseUrl.trim().replace(/\/+$/, '')}${cleanPath}`;
  }

  // 2. If running as a native Android / iOS app
  if (isNativePlatform()) {
    return `${DEFAULT_HOSTED_BACKEND_URL}${cleanPath}`;
  }

  // 3. In web development/preview, relative URL routes to local Express server
  return cleanPath;
}
