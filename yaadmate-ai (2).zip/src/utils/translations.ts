import { AppLanguage } from '../types/reminder';

export interface Translations {
  appName: string;
  tagline: string;
  tabs: {
    home: string;
    chat: string;
    history: string;
    whatsapp: string;
    settings: string;
  };
  greetings: {
    morning: string;
    afternoon: string;
    evening: string;
    night: string;
    welcomeBack: string;
  };
  stats: {
    today: string;
    upcoming: string;
    overdue: string;
    completed: string;
    total: string;
  };
  actions: {
    addReminder: string;
    save: string;
    cancel: string;
    delete: string;
    edit: string;
    complete: string;
    postpone: string;
    search: string;
    all: string;
    filter: string;
    clearCompleted: string;
    exportData: string;
    importData: string;
  };
  categories: {
    Work: string;
    Personal: string;
    Health: string;
    Shopping: string;
    Meeting: string;
    Important: string;
    Finance: string;
  };
  priorities: {
    urgent: string;
    high: string;
    medium: string;
    low: string;
  };
  recurrences: {
    none: string;
    daily: string;
    weekly: string;
    weekdays: string;
    monthly: string;
  };
  fields: {
    title: string;
    description: string;
    date: string;
    time: string;
    category: string;
    priority: string;
    recurrence: string;
    placeholderTitle: string;
    placeholderDesc: string;
  };
  postponeOptions: {
    title: string;
    m15: string;
    h1: string;
    h3: string;
    tomorrowMorning: string;
  };
  notifications: {
    title: string;
    desc: string;
    enableBtn: string;
    granted: string;
    denied: string;
    dismiss: string;
  };
  chat: {
    title: string;
    subtitle: string;
    inputPlaceholder: string;
    voiceListening: string;
    send: string;
    suggestionsTitle: string;
    confirmReminder: string;
    reminderCreated: string;
  };
}

export const translations: Record<AppLanguage, Translations> = {
  en: {
    appName: 'YaadMate AI',
    tagline: 'Never forget what matters most',
    tabs: {
      home: 'Dashboard',
      chat: 'AI Assistant',
      history: 'History',
      whatsapp: 'WhatsApp',
      settings: 'Settings',
    },
    greetings: {
      morning: 'Good morning',
      afternoon: 'Good afternoon',
      evening: 'Good evening',
      night: 'Good night',
      welcomeBack: 'Welcome back',
    },
    stats: {
      today: "Today's Tasks",
      upcoming: 'Upcoming',
      overdue: 'Overdue',
      completed: 'Completed',
      total: 'Total Active',
    },
    actions: {
      addReminder: 'New Reminder',
      save: 'Save Reminder',
      cancel: 'Cancel',
      delete: 'Delete',
      edit: 'Edit',
      complete: 'Mark Complete',
      postpone: 'Postpone',
      search: 'Search reminders...',
      all: 'All',
      filter: 'Filter',
      clearCompleted: 'Clear Completed',
      exportData: 'Export Backup',
      importData: 'Import Backup',
    },
    categories: {
      Work: 'Work',
      Personal: 'Personal',
      Health: 'Health',
      Shopping: 'Shopping',
      Meeting: 'Meeting',
      Important: 'Important',
      Finance: 'Finance',
    },
    priorities: {
      urgent: 'Urgent',
      high: 'High',
      medium: 'Medium',
      low: 'Low',
    },
    recurrences: {
      none: 'One-time',
      daily: 'Daily',
      weekly: 'Weekly',
      weekdays: 'Weekdays',
      monthly: 'Monthly',
    },
    fields: {
      title: 'Reminder Title',
      description: 'Notes / Description (Optional)',
      date: 'Date',
      time: 'Time',
      category: 'Category',
      priority: 'Priority',
      recurrence: 'Repeat',
      placeholderTitle: 'e.g. Doctor appointment, buy groceries...',
      placeholderDesc: 'Add any specific notes or location...',
    },
    postponeOptions: {
      title: 'Postpone Reminder',
      m15: '+15 minutes',
      h1: '+1 hour',
      h3: '+3 hours',
      tomorrowMorning: 'Tomorrow 9:00 AM',
    },
    notifications: {
      title: 'Stay Notified on Time',
      desc: 'Enable notifications so YaadMate can alert you the moment your reminder is due.',
      enableBtn: 'Enable Notifications',
      granted: 'Notifications active',
      denied: 'Notifications blocked in browser',
      dismiss: 'Later',
    },
    chat: {
      title: 'YaadMate AI Assistant',
      subtitle: 'Ask or speak in English, Urdu or Roman Urdu',
      inputPlaceholder: 'Ask YaadMate: e.g. "Remind me tomorrow at 8 AM to go to work"',
      voiceListening: 'Listening to your voice...',
      send: 'Send',
      suggestionsTitle: 'Try asking:',
      confirmReminder: 'Add This Reminder',
      reminderCreated: 'Reminder scheduled successfully!',
    },
  },

  'ur-roman': {
    appName: 'YaadMate AI',
    tagline: 'Zaroori kaam kabhi na bhooliay',
    tabs: {
      home: 'Dashboard',
      chat: 'AI Assistant',
      history: 'History',
      whatsapp: 'WhatsApp',
      settings: 'Settings',
    },
    greetings: {
      morning: 'Subah Bakhair',
      afternoon: 'Dopahar Bakhair',
      evening: 'Shaam Bakhair',
      night: 'Shab Bakhair',
      welcomeBack: 'Khush Amdeed',
    },
    stats: {
      today: 'Aaj ke Kaam',
      upcoming: 'Aane Wale',
      overdue: 'Takheer Shuda',
      completed: 'Mukammal',
      total: 'Kul Kaam',
    },
    actions: {
      addReminder: 'Naya Reminder',
      save: 'Mahfooz Karein',
      cancel: 'Mansookh',
      delete: 'Khatam Karein',
      edit: 'Tabdeeli Karein',
      complete: 'Mukammal Karein',
      postpone: 'Aage Badhayein',
      search: 'Reminders talash karein...',
      all: 'Tamam',
      filter: 'Filter',
      clearCompleted: 'Mukammal saaf karein',
      exportData: 'Backup Export',
      importData: 'Backup Import',
    },
    categories: {
      Work: 'Daftar / Kaam',
      Personal: 'Zaati',
      Health: 'Sehat & Dawa',
      Shopping: 'Kharidari',
      Meeting: 'Mulaqat',
      Important: 'Khaas Tareekh',
      Finance: 'Maaliyat / Bills',
    },
    priorities: {
      urgent: 'Aham Tareen',
      high: 'Zaroori',
      medium: 'Darmiana',
      low: 'Aam',
    },
    recurrences: {
      none: 'Aik martaba',
      daily: 'Rozana',
      weekly: 'Hafta-war',
      weekdays: 'Hafte ke din',
      monthly: 'Mahana',
    },
    fields: {
      title: 'Unwan (Title)',
      description: 'Wazahat / Notes',
      date: 'Tareekh',
      time: 'Waqt',
      category: 'Category',
      priority: 'Ahmiyat (Priority)',
      recurrence: 'Dohrayen (Repeat)',
      placeholderTitle: 'Jaise: Doctor se appointment, sabzi lana...',
      placeholderDesc: 'Koi khaas baat ya pata shamil karein...',
    },
    postponeOptions: {
      title: 'Reminder aage barhayein',
      m15: '+15 minute baad',
      h1: '+1 ghanta baad',
      h3: '+3 ghante baad',
      tomorrowMorning: 'Kal subah 9:00 baje',
    },
    notifications: {
      title: 'Barwaqt Ittila Payen',
      desc: 'Notifications allow karein taake YaadMate aapko theek waqt par aagah kar sake.',
      enableBtn: 'Notifications Shuru Karein',
      granted: 'Notifications faal hain',
      denied: 'Browser mein blocked hai',
      dismiss: 'Baad mein',
    },
    chat: {
      title: 'YaadMate AI Madadgaar',
      subtitle: 'Roman Urdu, Urdu ya English mein bolein ya likhein',
      inputPlaceholder: 'Maslan: "Kal subah 9 baje office meeting yaad karwana"',
      voiceListening: 'Aapki aawaz suni ja rahi hai...',
      send: 'Bhejein',
      suggestionsTitle: 'Aap keh sakte hain:',
      confirmReminder: 'Yeh Reminder Shamil Karein',
      reminderCreated: 'Reminder kamyabi se schedule ho gaya!',
    },
  },

  ur: {
    appName: 'یاد میٹ AI',
    tagline: 'ضروری کام کبھی نہ بھولیں',
    tabs: {
      home: 'ڈیش بورڈ',
      chat: 'AI معاون',
      history: 'تاریخچہ',
      whatsapp: 'واٹس ایپ',
      settings: 'ترتیبات',
    },
    greetings: {
      morning: 'صبح بخیر',
      afternoon: 'دوپہر بخیر',
      evening: 'شام بخیر',
      night: 'شب بخیر',
      welcomeBack: 'خوش آمدید',
    },
    stats: {
      today: 'آج کے کام',
      upcoming: 'آنے والے',
      overdue: 'تاخیر شدہ',
      completed: 'مکمل شدہ',
      total: 'کل کام',
    },
    actions: {
      addReminder: 'نیا یاد دہانی',
      save: 'محفوظ کریں',
      cancel: 'منسوخ',
      delete: 'حذف کریں',
      edit: 'ترمیم کریں',
      complete: 'مکمل کریں',
      postpone: 'آگے بڑھائیں',
      search: 'تلاش کریں...',
      all: 'تمام',
      filter: 'فلٹر',
      clearCompleted: 'مکمل شدہ صاف کریں',
      exportData: 'بیک اپ حاصل کریں',
      importData: 'بیک اپ بحال کریں',
    },
    categories: {
      Work: 'کام / دفتر',
      Personal: 'ذاتی',
      Health: 'صحت و دوا',
      Shopping: 'خریداری',
      Meeting: 'ملاقات',
      Important: 'اہم تاریخ',
      Finance: 'مالیات / بلز',
    },
    priorities: {
      urgent: 'فوری / شدید',
      high: 'اہم',
      medium: 'درمیانہ',
      low: 'عام',
    },
    recurrences: {
      none: 'ایک بار',
      daily: 'روزانہ',
      weekly: 'ہفتہ وار',
      weekdays: 'ہفتے کے دن',
      monthly: 'ماہانہ',
    },
    fields: {
      title: 'عنوان',
      description: 'تفصیل / نوٹس',
      date: 'تاریخ',
      time: 'وقت',
      category: 'زمرہ',
      priority: 'ترجیح',
      recurrence: 'دہرائیں',
      placeholderTitle: 'مثلاً: ڈاکٹر کا اپائنٹمنٹ، خریداری...',
      placeholderDesc: 'کوئی اہم نوٹ یا پتہ درج کریں...',
    },
    postponeOptions: {
      title: 'وقت آگے بڑھائیں',
      m15: '15 منٹ بعد',
      h1: '1 گھنٹہ بعد',
      h3: '3 گھنٹے بعد',
      tomorrowMorning: 'کل صبح 9:00 بجے',
    },
    notifications: {
      title: 'بروقت الرٹ حاصل کریں',
      desc: 'نوٹیفیکیشن فعال کریں تاکہ یاد میٹ آپ کو وقت پر اطلاع دے سکے۔',
      enableBtn: 'نوٹیفیکیشن آن کریں',
      granted: 'نوٹیفیکیشن فعال ہے',
      denied: 'براؤزر میں بلاک ہے',
      dismiss: 'بعد میں',
    },
    chat: {
      title: 'یاد میٹ AI اسسٹنٹ',
      subtitle: 'اردو، رومن اردو یا انگریزی میں بتائیں',
      inputPlaceholder: 'مثلاً: "کل صبح 8 بجے کام پر جانے کا یاد دلائیں"',
      voiceListening: 'آواز سنی جا رہی ہے...',
      send: 'بھیجیں',
      suggestionsTitle: 'مثال کے طور پر:',
      confirmReminder: 'یہ یاد دہانی شامل کریں',
      reminderCreated: 'یاد دہانی کامیابی سے شامل کر لی گئی!',
    },
  },
};
