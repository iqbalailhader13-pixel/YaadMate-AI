import { AppLanguage } from '../types/reminder';

/**
 * Checks if the Web Speech Synthesis API is supported by the current browser.
 */
export function isSpeechSynthesisSupported(): boolean {
  return typeof window !== 'undefined' && 'speechSynthesis' in window && 'SpeechSynthesisUtterance' in window;
}

/**
 * Stop any currently playing speech announcement.
 */
export function stopSpeaking(): void {
  if (isSpeechSynthesisSupported()) {
    try {
      window.speechSynthesis.cancel();
    } catch (err) {
      console.warn('Failed to cancel speech synthesis:', err);
    }
  }
}

/**
 * Announces a due reminder aloud using speech synthesis.
 */
export function speakReminderAnnouncement(
  title: string,
  category: string,
  language: AppLanguage
): void {
  if (!isSpeechSynthesisSupported()) return;

  try {
    // Cancel previous speech before starting
    stopSpeaking();

    let spokenText = '';
    let voiceLang = 'en-US';

    if (language === 'ur') {
      spokenText = `یاد دہانی۔ آپ کے کام، ${title}، کا وقت ہو گیا ہے۔`;
      voiceLang = 'ur-PK';
    } else if (language === 'ur-roman') {
      spokenText = `YaadMate reminder: Aapke task, ${title}, ka waqt ho gaya hai.`;
      voiceLang = 'ur-PK';
    } else {
      spokenText = `YaadMate reminder: It is time for ${title}. Category: ${category}.`;
      voiceLang = 'en-US';
    }

    const utterance = new SpeechSynthesisUtterance(spokenText);
    utterance.rate = 0.95; // Slightly slower, more clear and natural
    utterance.pitch = 1.0;
    utterance.volume = 1.0;

    // Pick best matching voice
    const voices = window.speechSynthesis.getVoices();
    if (voices && voices.length > 0) {
      // Look for ur-PK or ur-IN first if Urdu/Roman Urdu
      if (language === 'ur' || language === 'ur-roman') {
        const urduVoice = voices.find(
          (v) => v.lang.toLowerCase().startsWith('ur') || v.name.toLowerCase().includes('urdu')
        );
        if (urduVoice) {
          utterance.voice = urduVoice;
          utterance.lang = urduVoice.lang;
        } else {
          // Fallback to high quality English voice with phonetic clarity
          const enVoice = voices.find((v) => v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Google') || v.default));
          if (enVoice) utterance.voice = enVoice;
          utterance.lang = 'en-US';
        }
      } else {
        const enVoice = voices.find((v) => v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Google') || v.default));
        if (enVoice) {
          utterance.voice = enVoice;
          utterance.lang = enVoice.lang;
        } else {
          utterance.lang = 'en-US';
        }
      }
    }

    window.speechSynthesis.speak(utterance);
  } catch (err) {
    console.warn('Speech synthesis error:', err);
  }
}

/**
 * Reads any arbitrary text aloud (e.g., AI assistant conversational response)
 */
export function speakSpokenText(text: string, language: AppLanguage): void {
  if (!isSpeechSynthesisSupported() || !text.trim()) return;

  try {
    stopSpeaking();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.95;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;

    const voices = window.speechSynthesis.getVoices();
    if (voices && voices.length > 0) {
      if (language === 'ur' || language === 'ur-roman') {
        const urduVoice = voices.find(
          (v) => v.lang.toLowerCase().startsWith('ur') || v.name.toLowerCase().includes('urdu')
        );
        if (urduVoice) {
          utterance.voice = urduVoice;
          utterance.lang = urduVoice.lang;
        } else {
          utterance.lang = 'en-US';
        }
      } else {
        const enVoice = voices.find(
          (v) =>
            v.lang.startsWith('en') &&
            (v.name.includes('Natural') || v.name.includes('Google') || v.default)
        );
        if (enVoice) utterance.voice = enVoice;
        utterance.lang = 'en-US';
      }
    }

    window.speechSynthesis.speak(utterance);
  } catch (err) {
    console.warn('Speech synthesis error:', err);
  }
}
