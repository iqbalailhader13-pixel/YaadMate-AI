import { Reminder, UserPreferences } from '../types/reminder';

const REMINDERS_KEY = 'yaadmate_reminders_v1';
const PREFS_KEY = 'yaadmate_preferences_v1';

// Generate default realistic reminders relative to current date
export function getInitialReminders(): Reminder[] {
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];

  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];

  const in3Days = new Date(now);
  in3Days.setDate(in3Days.getDate() + 3);
  const in3DaysStr = in3Days.toISOString().split('T')[0];

  return [
    {
      id: 'rem-1',
      title: 'Morning Team Standup & Project Sync',
      description: 'Discuss sprint goals, blockers, and client updates on Google Meet.',
      date: todayStr,
      time: '10:00',
      category: 'Work',
      priority: 'high',
      recurrence: 'weekdays',
      completed: false,
      createdAt: new Date().toISOString(),
      postponeCount: 0,
    },
    {
      id: 'rem-2',
      title: 'Hydration & Posture Break',
      description: 'Drink 2 glasses of water and do a quick 2-minute spinal stretch.',
      date: todayStr,
      time: '14:30',
      category: 'Health',
      priority: 'medium',
      recurrence: 'daily',
      completed: false,
      createdAt: new Date().toISOString(),
      postponeCount: 0,
    },
    {
      id: 'rem-3',
      title: 'Call Family & Ammi Check-in',
      description: 'Catch up on weekend plans and family dinner.',
      date: todayStr,
      time: '20:00',
      category: 'Personal',
      priority: 'high',
      recurrence: 'daily',
      completed: false,
      createdAt: new Date().toISOString(),
      postponeCount: 0,
    },
    {
      id: 'rem-4',
      title: 'Weekly Grocery & Fresh Produce Market',
      description: 'Buy milk, yogurt, whole wheat flour, fresh vegetables, and fruits.',
      date: tomorrowStr,
      time: '18:00',
      category: 'Shopping',
      priority: 'medium',
      recurrence: 'weekly',
      completed: false,
      createdAt: new Date().toISOString(),
      postponeCount: 0,
    },
    {
      id: 'rem-5',
      title: 'Pay Electricity & Internet Bills',
      description: 'Check billing portal and settle via mobile banking app before due date.',
      date: in3DaysStr,
      time: '11:00',
      category: 'Finance',
      priority: 'urgent',
      recurrence: 'monthly',
      completed: false,
      createdAt: new Date().toISOString(),
      postponeCount: 0,
    },
  ];
}

export function loadReminders(): Reminder[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(REMINDERS_KEY);
    if (!raw) {
      const initial = getInitialReminders();
      saveReminders(initial);
      return initial;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed;
    }
    return getInitialReminders();
  } catch (err) {
    console.error('Failed to load reminders from localStorage:', err);
    return getInitialReminders();
  }
}

export function saveReminders(reminders: Reminder[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(REMINDERS_KEY, JSON.stringify(reminders));
  } catch (err) {
    console.error('Failed to save reminders:', err);
  }
}

export const defaultPreferences: UserPreferences = {
  language: 'en',
  theme: 'navy',
  soundEnabled: true,
  vibrateEnabled: true,
  speechAnnouncementsEnabled: true,
  alarmSound: 'melodic',
  leadTimeMinutes: 0,
  userName: 'Friend',
  hasSeenOnboarding: false,
};

export function loadPreferences(): UserPreferences {
  if (typeof window === 'undefined') return defaultPreferences;
  try {
    const raw = localStorage.getItem(PREFS_KEY);
    if (!raw) return defaultPreferences;
    return { ...defaultPreferences, ...JSON.parse(raw) };
  } catch {
    return defaultPreferences;
  }
}

export function savePreferences(prefs: UserPreferences): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
  } catch (err) {
    console.error('Failed to save preferences:', err);
  }
}
