import 'dotenv/config';
import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// Enable CORS for native Android Capacitor app (origin: https://localhost or capacitor://localhost)
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
    return;
  }
  next();
});

// Initialize GoogleGenAI server-side with User-Agent header as required
const apiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;
if (apiKey) {
  aiClient = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Fallback rule-based parser for when API key is missing or offline
function fallbackParseReminder(text: string, refDateStr?: string) {
  const refDate = refDateStr ? new Date(refDateStr) : new Date();

  // Normalize Urdu/Arabic numerals to standard digits (۰-۹ to 0-9)
  let normalized = text
    .replace(/[۰٠]/g, '0')
    .replace(/[۱١]/g, '1')
    .replace(/[۲٢]/g, '2')
    .replace(/[۳٣]/g, '3')
    .replace(/[۴٤]/g, '4')
    .replace(/[۵٥]/g, '5')
    .replace(/[۶٦]/g, '6')
    .replace(/[۷٧]/g, '7')
    .replace(/[۸٨]/g, '8')
    .replace(/[۹٩]/g, '9');

  const lower = normalized.toLowerCase().trim();

  // Determine priority
  let priority: 'low' | 'medium' | 'high' | 'urgent' = 'medium';
  if (
    lower.includes('urgent') ||
    lower.includes('zaruri') ||
    lower.includes('zaroori') ||
    lower.includes('foran') ||
    lower.includes('asap') ||
    lower.includes('فوری') ||
    lower.includes('شدید')
  ) {
    priority = 'urgent';
  } else if (
    lower.includes('important') ||
    lower.includes('high') ||
    lower.includes('khaas') ||
    lower.includes('lazmi') ||
    lower.includes('اہم') ||
    lower.includes('ضروری')
  ) {
    priority = 'high';
  } else if (
    lower.includes('low') ||
    lower.includes('aaram se') ||
    lower.includes('casual') ||
    lower.includes('عام')
  ) {
    priority = 'low';
  }

  // Determine category
  let category: 'Work' | 'Personal' | 'Health' | 'Shopping' | 'Meeting' | 'Important' | 'Finance' = 'Personal';
  if (
    lower.includes('meeting') ||
    lower.includes('call') ||
    lower.includes('zoom') ||
    lower.includes('interview') ||
    lower.includes('mulaqat') ||
    lower.includes('ملاقات') ||
    lower.includes('میٹنگ')
  ) {
    category = 'Meeting';
  } else if (
    lower.includes('work') ||
    lower.includes('office') ||
    lower.includes('kaam') ||
    lower.includes('project') ||
    lower.includes('deadline') ||
    lower.includes('task') ||
    lower.includes('کام') ||
    lower.includes('دفتر')
  ) {
    category = 'Work';
  } else if (
    lower.includes('medicine') ||
    lower.includes('dawa') ||
    lower.includes('dawai') ||
    lower.includes('doctor') ||
    lower.includes('water') ||
    lower.includes('paani') ||
    lower.includes('gym') ||
    lower.includes('walk') ||
    lower.includes('exercise') ||
    lower.includes('دوا') ||
    lower.includes('دوائی') ||
    lower.includes('پانی') ||
    lower.includes('صحت')
  ) {
    category = 'Health';
  } else if (
    lower.includes('shopping') ||
    lower.includes('buy') ||
    lower.includes('kharid') ||
    lower.includes('grocery') ||
    lower.includes('sabzi') ||
    lower.includes('market') ||
    lower.includes('milk') ||
    lower.includes('doodh') ||
    lower.includes('خریداری') ||
    lower.includes('سبزی') ||
    lower.includes('دودھ') ||
    lower.includes('سودا')
  ) {
    category = 'Shopping';
  } else if (
    lower.includes('bill') ||
    lower.includes('bank') ||
    lower.includes('fee') ||
    lower.includes('rent') ||
    lower.includes('salary') ||
    lower.includes('paisa') ||
    lower.includes('paise') ||
    lower.includes('بل') ||
    lower.includes('بینک') ||
    lower.includes('فیس') ||
    lower.includes('کرایہ')
  ) {
    category = 'Finance';
  }

  // Determine recurrence
  let recurrence: 'none' | 'daily' | 'weekly' | 'weekdays' | 'monthly' = 'none';
  if (
    lower.includes('every day') ||
    lower.includes('daily') ||
    lower.includes('har roz') ||
    lower.includes('rozana') ||
    lower.includes('roz') ||
    lower.includes('ہر روز') ||
    lower.includes('روزانہ')
  ) {
    recurrence = 'daily';
  } else if (
    lower.includes('every week') ||
    lower.includes('weekly') ||
    lower.includes('har hafte') ||
    lower.includes('ہر ہفتے')
  ) {
    recurrence = 'weekly';
  } else if (
    lower.includes('every month') ||
    lower.includes('monthly') ||
    lower.includes('har maheenay') ||
    lower.includes('har mahine') ||
    lower.includes('ہر ماہ') ||
    lower.includes('ماہانہ')
  ) {
    recurrence = 'monthly';
  } else if (lower.includes('weekdays') || lower.includes('mon to fri') || lower.includes('ہفتے کے دن')) {
    recurrence = 'weekdays';
  }

  // Determine Target Date
  const targetDate = new Date(refDate);
  if (
    lower.includes('tomorrow') ||
    lower.includes('kal') ||
    lower.includes('subah kal') ||
    lower.includes('کل')
  ) {
    targetDate.setDate(targetDate.getDate() + 1);
  } else if (
    lower.includes('day after tomorrow') ||
    lower.includes('parson') ||
    lower.includes('tarson') ||
    lower.includes('پرسوں')
  ) {
    targetDate.setDate(targetDate.getDate() + 2);
  } else if (lower.includes('next week') || lower.includes('agle hafte') || lower.includes('اگلے ہفتے')) {
    targetDate.setDate(targetDate.getDate() + 7);
  } else if (
    lower.includes('next friday') ||
    lower.includes('agle jummay') ||
    lower.includes('jumma') ||
    lower.includes('جمعہ')
  ) {
    const day = targetDate.getDay();
    const diff = (5 + 7 - day) % 7 || 7;
    targetDate.setDate(targetDate.getDate() + diff);
  } else if (lower.includes('next monday') || lower.includes('peer') || lower.includes('پیر')) {
    const day = targetDate.getDay();
    const diff = (1 + 7 - day) % 7 || 7;
    targetDate.setDate(targetDate.getDate() + diff);
  }

  // Determine Target Time with advanced English, Urdu, and Roman Urdu understanding
  let timeStr = '09:00';
  const timeRegex12 = /(\b\d{1,2})(?::(\d{2}))?\s*(am|pm)\b/i;
  const match12 = lower.match(timeRegex12);

  const urduTimeRegex = /(\b\d{1,2})(?::(\d{2}))?\s*(?:baje|بجے)\b/i;
  const urduMatch = lower.match(urduTimeRegex);

  // Urdu word numbers mapping
  const urduWordNumbers: Record<string, number> = {
    'ek': 1, 'ایک': 1,
    'do': 2, 'دو': 2,
    'teen': 3, 'تین': 3,
    'chaar': 4, 'char': 4, 'چار': 4,
    'paanch': 5, 'panch': 5, 'پانچ': 5,
    'chhe': 6, 'che': 6, 'چھ': 6,
    'saat': 7, 'سات': 7,
    'aath': 8, 'آٹھ': 8,
    'nau': 9, 'نو': 9,
    'das': 10, 'دس': 10,
    'gyarah': 11, 'گیارہ': 11,
    'barah': 12, 'baarah': 12, 'بارہ': 12,
  };

  // Check for fractional times like "saadhe 8", "sawa 9", "paune 10", "dedh baje", "dhai baje"
  const isSaadhe = lower.includes('saadhe') || lower.includes('sadhe') || lower.includes('ساڑھے');
  const isSawa = lower.includes('sawa') || lower.includes('سوا');
  const isPaune = lower.includes('paune') || lower.includes('pawne') || lower.includes('پونے');
  const isDedh = lower.includes('dedh') || lower.includes('ڈیڑھ');
  const isDhai = lower.includes('dhai') || lower.includes('ڈھائی');

  if (match12) {
    let hour = parseInt(match12[1], 10);
    const minute = match12[2] ? match12[2].padStart(2, '0') : '00';
    const period = match12[3].toLowerCase();
    if (period === 'pm' && hour < 12) hour += 12;
    if (period === 'am' && hour === 12) hour = 0;
    timeStr = `${String(hour).padStart(2, '0')}:${minute}`;
  } else if (isDedh) {
    const isNight = lower.includes('raat') || lower.includes('shaam') || lower.includes('رات');
    timeStr = isNight ? '01:30' : '13:30';
  } else if (isDhai) {
    const isNight = lower.includes('raat') || lower.includes('رات');
    timeStr = isNight ? '02:30' : '14:30';
  } else if (urduMatch) {
    let hour = parseInt(urduMatch[1], 10);
    let minute = urduMatch[2] ? urduMatch[2].padStart(2, '0') : '00';
    if (isSaadhe) minute = '30';
    if (isSawa) minute = '15';
    if (isPaune) {
      minute = '45';
      hour = hour > 1 ? hour - 1 : 12;
    }
    if ((lower.includes('shaam') || lower.includes('raat') || lower.includes('شام') || lower.includes('رات')) && hour < 12) {
      hour += 12;
    } else if ((lower.includes('dopahar') || lower.includes('دوپہر')) && hour < 12 && hour !== 12) {
      if (hour < 5) hour += 12;
    }
    timeStr = `${String(hour).padStart(2, '0')}:${minute}`;
  } else {
    // Check Urdu word numerals (e.g. "shaam saat baje", "subah aath baje")
    let wordHour = 0;
    for (const [w, num] of Object.entries(urduWordNumbers)) {
      if (lower.includes(`${w} baje`) || lower.includes(`${w}بجے`)) {
        wordHour = num;
        break;
      }
    }

    if (wordHour > 0) {
      let minute = '00';
      if (isSaadhe) minute = '30';
      if (isSawa) minute = '15';
      if (isPaune) {
        minute = '45';
        wordHour = wordHour > 1 ? wordHour - 1 : 12;
      }
      if ((lower.includes('shaam') || lower.includes('raat') || lower.includes('شام') || lower.includes('رات')) && wordHour < 12) {
        wordHour += 12;
      } else if ((lower.includes('dopahar') || lower.includes('دوپہر')) && wordHour < 12 && wordHour !== 12) {
        if (wordHour < 5) wordHour += 12;
      }
      timeStr = `${String(wordHour).padStart(2, '0')}:${minute}`;
    } else if (lower.includes('fajr') || lower.includes('فجر') || lower.includes('sehri') || lower.includes('سحری')) {
      timeStr = '05:00';
    } else if (lower.includes('zohr') || lower.includes('zuhr') || lower.includes('ظہر') || lower.includes('lunch')) {
      timeStr = '13:30';
    } else if (lower.includes('asr') || lower.includes('عصر')) {
      timeStr = '16:45';
    } else if (lower.includes('maghrib') || lower.includes('مغرب') || lower.includes('iftar') || lower.includes('افطار')) {
      timeStr = '18:15';
    } else if (lower.includes('isha') || lower.includes('عشاء')) {
      timeStr = '20:15';
    } else if (lower.includes('nashta') || lower.includes('breakfast') || lower.includes('ناشتہ')) {
      timeStr = '08:30';
    } else if (lower.includes('dinner') || lower.includes('khana') || lower.includes('کھانا')) {
      timeStr = '20:30';
    } else if (lower.includes('morning') || lower.includes('subah') || lower.includes('صبح')) {
      timeStr = '08:00';
    } else if (lower.includes('afternoon') || lower.includes('dopahar') || lower.includes('دوپہر')) {
      timeStr = '14:00';
    } else if (lower.includes('evening') || lower.includes('shaam') || lower.includes('شام')) {
      timeStr = '18:00';
    } else if (lower.includes('night') || lower.includes('raat') || lower.includes('رات')) {
      timeStr = '21:00';
    }
  }

  // Clean title in English, Roman Urdu, and Urdu script
  let cleanedTitle = text
    .replace(/^remind me to\s+/i, '')
    .replace(/^remind me about\s+/i, '')
    .replace(/^remind me\s+/i, '')
    .replace(/^yaad dila(o|na|iye)?\s*(k|ke)?/i, '')
    .replace(/^mujhe yaad (karwao|karwana|dilao)\s*/i, '')
    .replace(/^(یاد دلائیں|یاد کروانا|مجھے یاد دلائیں)\s*/gi, '')
    .replace(/\b(day after tomorrow|parson|tarson|پرسوں)\b/gi, '')
    .replace(/\b(tomorrow|today|kal|yesterday|کل|آج)\b/gi, '')
    .replace(/\bat\s+\d{1,2}(:\d{2})?\s*(am|pm)?\b/gi, '')
    .replace(/\b\d{1,2}(:\d{2})?\s*(am|pm)\b/gi, '')
    .replace(/\b\d{1,2}\s*(?:baje|بجے)\b/gi, '')
    .replace(/\b(subah|shaam|raat|dopahar|صبح|شام|رات|دوپہر)\b/gi, '')
    .replace(/\b(every day|daily|har roz|rozana|weekly|monthly|ہر روز|روزانہ)\b/gi, '')
    .replace(/\b(ka|ki|ke|yaad karwana|yaad dilana|batao|کا|کی|کے|یاد دلائیں)\b/gi, '')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/^to\s+/i, '');

  if (!cleanedTitle || cleanedTitle.length < 2) {
    cleanedTitle = text.trim();
  }

  const yyyy = targetDate.getFullYear();
  const mm = String(targetDate.getMonth() + 1).padStart(2, '0');
  const dd = String(targetDate.getDate()).padStart(2, '0');
  const dateStr = `${yyyy}-${mm}-${dd}`;

  return {
    title: cleanedTitle.charAt(0).toUpperCase() + cleanedTitle.slice(1),
    description: `Created via natural language: "${text}"`,
    date: dateStr,
    time: timeStr,
    category,
    priority,
    recurrence,
    explanation: `Scheduled for ${dateStr} at ${timeStr} (${category}).`,
    isAiPowered: false,
  };
}

// API to check Gemini configuration status
app.get('/api/status', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    hasGeminiKey: Boolean(apiKey),
    appName: 'YaadMate AI',
    timestamp: new Date().toISOString(),
  });
});

// Helper to call Gemini with timeout and model fallback
async function generateContentWithFallback(params: {
  contents: any;
  systemInstruction?: string;
  responseSchema?: any;
}) {
  if (!aiClient) throw new Error('AI client not initialized');

  const modelsToTry = ['gemini-3.8-flash', 'gemini-flash-latest'];
  let lastError: any = null;

  for (const model of modelsToTry) {
    try {
      const config: any = {
        systemInstruction: params.systemInstruction,
        responseMimeType: 'application/json',
      };
      if (params.responseSchema) {
        config.responseSchema = params.responseSchema;
      }

      // 6 second timeout race
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error('AI request timeout')), 6000)
      );

      const apiPromise = aiClient.models.generateContent({
        model,
        contents: params.contents,
        config,
      });

      const response: any = await Promise.race([apiPromise, timeoutPromise]);
      return response;
    } catch (err: any) {
      lastError = err;
      console.warn(`Model ${model} issue:`, err.message || err);
    }
  }

  throw lastError;
}

// API endpoint: Parse a single reminder request
app.post('/api/gemini/parse-reminder', async (req: Request, res: Response) => {
  const rawInput = req.body.text || req.body.prompt;
  const { currentDateTime } = req.body;
  const text = typeof rawInput === 'string' ? rawInput.trim() : '';

  if (!text) {
    res.status(400).json({ error: 'Text prompt is required.' });
    return;
  }

  const nowRef = currentDateTime || new Date().toISOString();

  // If Gemini client is not initialized, return the rule-based parsed output
  if (!aiClient) {
    const parsed = fallbackParseReminder(text, nowRef);
    res.json({ ...parsed, notice: 'Running with high-precision offline parser.' });
    return;
  }

  try {
    const systemPrompt = `You are YaadMate AI, an expert reminder parsing assistant.
The current date and time is: ${nowRef}.
The user may give commands in English, Urdu (اردو), or Roman Urdu (e.g. "Kal subah 9 baje meeting", "Remind me tomorrow at 8 AM to go to work", "Har roz raat 9 baje pani peena").
Extract the reminder details accurately:
- title: concise title of the task
- description: helpful extra details or blank string
- date: YYYY-MM-DD. Calculate relative dates ("tomorrow" / "kal", "next friday", etc.) based strictly on current date ${nowRef}.
- time: HH:MM in 24-hour format (e.g. 08:00, 21:00). Default to 09:00 if not specified.
- category: One of ['Work', 'Personal', 'Health', 'Shopping', 'Meeting', 'Important', 'Finance'].
- priority: One of ['low', 'medium', 'high', 'urgent'].
- recurrence: One of ['none', 'daily', 'weekly', 'weekdays', 'monthly'].
- explanation: A friendly, supportive confirmation sentence in the SAME language the user used (English, Urdu, or Roman Urdu).`;

    const response = await generateContentWithFallback({
      contents: text,
      systemInstruction: systemPrompt,
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING },
          date: { type: Type.STRING },
          time: { type: Type.STRING },
          category: {
            type: Type.STRING,
            enum: ['Work', 'Personal', 'Health', 'Shopping', 'Meeting', 'Important', 'Finance'],
          },
          priority: {
            type: Type.STRING,
            enum: ['low', 'medium', 'high', 'urgent'],
          },
          recurrence: {
            type: Type.STRING,
            enum: ['none', 'daily', 'weekly', 'weekdays', 'monthly'],
          },
          explanation: { type: Type.STRING },
        },
        required: ['title', 'date', 'time', 'category', 'priority', 'recurrence', 'explanation'],
      },
    });

    const parsedJson = JSON.parse(response.text || '{}');
    res.json({ ...parsedJson, isAiPowered: true });
  } catch (error) {
    console.error('Gemini API parse error, falling back to local parser:', error);
    const parsed = fallbackParseReminder(text, nowRef);
    res.json({ ...parsed, isAiPowered: false, notice: 'Switched to local parser due to temporary AI request limit.' });
  }
});

// API endpoint: Conversational Assistant with multi-turn support and smart task handling
app.post('/api/gemini/chat', async (req: Request, res: Response) => {
  const { message, history = [], reminders = [], currentDateTime, userLanguage = 'en' } = req.body;

  if (!message || typeof message !== 'string') {
    res.status(400).json({ error: 'Message is required.' });
    return;
  }

  const nowRef = currentDateTime || new Date().toISOString();

  // If Gemini is not configured, deliver a smart conversational response
  if (!aiClient) {
    const lower = message.toLowerCase();
    if (lower.includes('show') || lower.includes('list') || lower.includes('pending') || lower.includes('batao') || lower.includes('kaam')) {
      const pendingCount = (reminders as Array<{ completed?: boolean }>).filter(r => !r.completed).length;
      res.json({
        reply: `You currently have **${pendingCount} pending reminders**. You can view, filter, and mark them on the main dashboard.\n\n*Note: Operating in local parser mode. Add your GEMINI_API_KEY in Settings > Secrets for full conversational intelligence.*`,
        suggestedAction: { type: 'view_reminders' },
      });
      return;
    }

    // Attempt to parse reminder
    const parsed = fallbackParseReminder(message, nowRef);
    res.json({
      reply: `I detected a reminder request! Would you like me to schedule: **"${parsed.title}"** for **${parsed.date} at ${parsed.time}** (${parsed.category}, ${parsed.priority} priority)?`,
      suggestedAction: {
        type: 'confirm_reminder',
        reminder: parsed,
      },
    });
    return;
  }

  try {
    const remindersContext = JSON.stringify(reminders.slice(0, 25).map((r: any) => ({
      id: r.id,
      title: r.title,
      date: r.date,
      time: r.time,
      category: r.category,
      priority: r.priority,
      completed: r.completed,
      recurrence: r.recurrence,
    })));

    const systemPrompt = `You are "YaadMate AI", a thoughtful, charming, and highly capable personal reminder assistant.
Current Date & Time: ${nowRef}
User Preferred Language: ${userLanguage}
Current Reminders in App: ${remindersContext}

Capabilities:
1. When the user asks to be reminded (in English, Urdu, or Roman Urdu), recognize it as a reminder creation intent. Include a JSON action block for the app to create the reminder if appropriate.
2. When the user asks about their tasks ("show me pending tasks", "aaj ke kya kaam hain?", "do I have any meetings?"), summarize clearly from their current reminders list.
3. Be respectful, encouraging, and natural. Use appropriate cultural warmth (e.g. "Assalam-o-Alaikum", "Shab-bakhair", or friendly English greetings).
4. Output JSON schema with:
   - "reply": The conversational text to show the user (supports Markdown formatting, bullet points, bolding).
   - "action": (Optional) If user intended to create a reminder, include the parsed reminder object:
     {
       "type": "create_reminder",
       "data": {
         "title": string,
         "description": string,
         "date": "YYYY-MM-DD",
         "time": "HH:MM",
         "category": "Work" | "Personal" | "Health" | "Shopping" | "Meeting" | "Important" | "Finance",
         "priority": "low" | "medium" | "high" | "urgent",
         "recurrence": "none" | "daily" | "weekly" | "weekdays" | "monthly"
       }
     }
     Or if user wanted to view pending:
     {
       "type": "view_reminders"
     }
`;

    const contents = [
      ...history.map((h: any) => ({
        role: h.role === 'user' ? 'user' : 'model',
        parts: [{ text: h.text }],
      })),
      {
        role: 'user',
        parts: [{ text: message }],
      },
    ];

    const response = await generateContentWithFallback({
      contents: contents as any,
      systemInstruction: systemPrompt,
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          reply: { type: Type.STRING },
          action: {
            type: Type.OBJECT,
            properties: {
              type: { type: Type.STRING },
              data: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  description: { type: Type.STRING },
                  date: { type: Type.STRING },
                  time: { type: Type.STRING },
                  category: { type: Type.STRING },
                  priority: { type: Type.STRING },
                  recurrence: { type: Type.STRING },
                },
              },
            },
          },
        },
        required: ['reply'],
      },
    });

    const parsedJson = JSON.parse(response.text || '{}');
    res.json(parsedJson);
  } catch (error) {
    console.error('Gemini chat error, using local conversational fallback:', error);
    const lower = message.toLowerCase();
    if (
      lower.includes('show') ||
      lower.includes('list') ||
      lower.includes('pending') ||
      lower.includes('batao') ||
      lower.includes('kaam') ||
      lower.includes('tasks') ||
      lower.includes('schedule')
    ) {
      const activeReminders = (reminders as any[]).filter((r) => !r.completed);
      if (activeReminders.length === 0) {
        res.json({
          reply:
            'You currently have no active pending tasks! All caught up. You can tap the **+** button or say "Remind me..." to add one.',
          action: { type: 'view_reminders' },
        });
      } else {
        const listText = activeReminders
          .slice(0, 5)
          .map((r) => `• **${r.title}** (${r.date} at ${r.time}) — *${r.category}* [${r.priority}]`)
          .join('\n');
        res.json({
          reply: `You have **${activeReminders.length} active tasks**:\n\n${listText}\n\nYou can view and manage all of them on your Dashboard.`,
          action: { type: 'view_reminders' },
        });
      }
      return;
    }

    const parsed = fallbackParseReminder(message, nowRef);
    res.json({
      reply: `I detected your reminder request: **"${parsed.title}"** scheduled for **${parsed.date} at ${parsed.time}** (${parsed.category}, ${parsed.priority} priority). Confirm below to add it directly to your reminders.`,
      action: {
        type: 'create_reminder',
        data: parsed,
      },
    });
  }
});

// Mount Vite or static server
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`YaadMate AI server is running on port ${PORT}`);
  });
}

startServer();
